from copier_templates_extensions import ContextHook
from copier.errors import UserMessageError
import re


class ContextUpdater(ContextHook):
    update = False

    # These 3 must be replaced by maven's filtering
    docker_image_development="universalrobots/urcap_polyscopex_ros2:5.0.2-jazzy-dev"
    docker_image_runtime="universalrobots/urcap_polyscopex_ros2:5.0.2-jazzy-runtime"
    docker_image_proxy=""

    # camel case strings. Fx my-awesome-string -> MyAwesomeString
    def to_camelcase(self, input_str):
        input_str = input_str.strip()  # Trim whitespace
        return input_str[0].upper() + re.sub(r'-(.)', lambda x: x.group(1).upper(), input_str[1:].lower())

    # Replace hyphen (dash) with whitespace and capitalize next word
    def to_title(self, input_str):
        return ' '.join(word.capitalize() for word in input_str.replace("-", " ").split())

    # replace . and _ with -
    def to_ROS2_node_name(self, input):
        return re.sub(r'[.-]', '_', input.lower().strip())

    # replace . and - with _
    def to_tag_name(self, input):
        return re.sub(r'[._]', '-', input.lower().strip())

    def buildItem(self, elementName, base_tag):
        return {
                  "elementComponentName": self.to_camelcase(elementName),
                  "elementNodeTitle": self.to_title(elementName),
                  "elementTagName": self.to_tag_name(base_tag + elementName),
                  "elementNodeName": elementName,
               }

    def hook(self, context):
        if context.get("operatorScreens") is not None: # This must be the key to the last questions asked
            if not context["includeFrontend"] and not context["includeDocker"]:
                raise UserMessageError("Invalid combination chosen! Include either a frontend or a backend to generate a valid URCap. Rerun the generator to restart")

            base_tag = self.to_tag_name(context["vendorId"]) + "-" + self.to_tag_name(context["urcapId"]) + "-"
            context["artifactId"] = context.get("urcapId")

            if context["includeFrontend"]:
                named_sublists = {}
                if context["hasApplicationNode"]:
                    named_sublists["applicationNodeList"] = [self.buildItem(element, base_tag) for element in context["applicationNodes"].split(",")]

                if context["hasProgramNode"]:
                    named_sublists["programNodeList"] = [self.buildItem(element, base_tag) for element in context["programNodes"].split(",")]

                if context["hasSmartSkill"]:
                    named_sublists["smartSkillList"] = [self.buildItem(element, base_tag) for element in context["smartSkills"].split(",")]

                if context["hasSidebar"]:
                    named_sublists["sidebarItemList"] = [self.buildItem(element, base_tag) for element in context["sidebarItems"].split(",")]

                if context["hasOperatorScreen"]:
                    named_sublists["operatorScreenList"] = [self.buildItem(element, base_tag) for element in context["operatorScreens"].split(",")]

                if not named_sublists:
                    raise UserMessageError("Invalid combination chosen! Include at least one frontend component to generate a valid URCap. Rerun the generator to restart")

                context["named_sublists"] = named_sublists

                all_elements_flattened = [
                    item for sublist in named_sublists.values() for item in sublist
                ]

                context["allElementsFlattened"] = all_elements_flattened

            if not context["includeFrontend"] and context["includeDocker"]:
                context["dockerOnly"] = True
                context["FrontendType"] = ''


            context["ros2NodeName"] = self.to_ROS2_node_name(context.get("urcapId"))
            context["ros2NodeDesc"] = context.get("urcapId")

            # TODO REMOVE WHEN MAVEN BUILDS THESE
            context["docker_developmentimage"] = self.docker_image_development
            context["docker_runtimeimage"] = self.docker_image_runtime
            context["docker_sampleproxy"] = self.docker_image_proxy
            context["frontendId"] = context.get("urcapId")+"-frontend"
            context["backendId"] = context.get("urcapId")+"-backend"
            context["subdirectory"] = "frontend_and_backend"