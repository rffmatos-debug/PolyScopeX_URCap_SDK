{%- if named_sublists["applicationNodeList"] %} {%- for item in named_sublists["applicationNodeList"] %}
import { {{ item.elementComponentName }}Component } from './{{ item.elementNodeName }}/{{ item.elementNodeName }}.component';
{%- endfor %}
{% endif -%}
{% if named_sublists["programNodeList"] %} {%- for item in named_sublists["programNodeList"] %}
import { {{ item.elementComponentName }}Component } from './{{ item.elementNodeName}}/{{ item.elementNodeName }}.component';
{%- endfor %}
{% endif -%}
