const api = require('@universal-robots/contribution-api');

const behaviors = {
  factory: createOperatorScreenInstance,
};

// factory is required
async function createOperatorScreenInstance() {
  return {
    type: '{{ item.elementTagName }}',
    name: '{{ item.elementNodeTitle }}',
    parameters: {},
  };
}


api.registerOperatorScreenBehavior(behaviors);
