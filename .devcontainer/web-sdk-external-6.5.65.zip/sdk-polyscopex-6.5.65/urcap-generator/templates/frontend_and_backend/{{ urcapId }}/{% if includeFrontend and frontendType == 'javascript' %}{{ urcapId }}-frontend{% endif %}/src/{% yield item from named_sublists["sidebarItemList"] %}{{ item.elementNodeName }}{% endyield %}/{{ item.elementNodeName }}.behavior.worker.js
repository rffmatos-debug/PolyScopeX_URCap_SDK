const api = require('@universal-robots/contribution-api');

const behaviors = {
  factory: createSidebarInstance,
};

// factory is required
async function createSidebarInstance() {
  return {
    type: '{{ item.elementTagName }}',
    name: '{{ item.elementNodeTitle }}',
    parameters: {},
  };
}


api.registerSidebarBehavior(behaviors);
