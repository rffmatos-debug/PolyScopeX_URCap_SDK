# {% if frontendType == 'angular' %}Angular contribution{% else %}Javascript contribution{% endif %}

This project is a template example of a URCap containing a Web frontend and a{% if includeRos %}ROS2{% endif %} Docker backend

## Build and Deploy Sample

To build and deploy this sample, use the commands below. A rebuild of the project is required to see any changes made 
to the source code. If you are deploying the URCap to URSim, ensure that you have started the simulator.

### Dependencies

Run this command to install the dependencies of the project.

```shell
npm install
```

### Build

Run this command to build the contribution type.

```shell
npm run build
```

### Installation

Run this command to install the built URCap to the simulator.

```shell
npm run install-urcap
```

Run this command to install the built URCap to the robot.

```shell
npm run install-urcap -- --host <robot_ip_address>
````


## Further help

Get more help from the included SDK documentation.
