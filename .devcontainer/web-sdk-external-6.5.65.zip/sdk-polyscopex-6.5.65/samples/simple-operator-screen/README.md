# Angular contribution

This project contains an example of a URCap Operator Screen Contribution.
When the sample has been installed, it is possible to change
the Operator Screen from the Application menu "Operator Screen".

Refer to the Operator Screen contribution section in
the [official documentation](https://docs.universal-robots.com/PolyScopeX_SDK_Documentation) for more information.

## Build and Deploy Sample

To build and deploy this sample, use the commands below. A rebuild of the project is required to see any changes made 
to the source code. If you are deploying the URCap to URSim, ensure that you have started the simulator.

### Dependencies

Run this command to install the dependencies of the project.

```shell
npm install
```

### Build

Run this command to build the contribution type.

```shell
npm run build
```

### Installation

Run this command to install the built URCap to the simulator.

```shell
npm run install-urcap
```

Run this command to install the built URCap to the robot.

```shell
npm run install-urcap -- --host <robot_ip_address>
````


## Further help

Get more help from the included SDK documentation.
