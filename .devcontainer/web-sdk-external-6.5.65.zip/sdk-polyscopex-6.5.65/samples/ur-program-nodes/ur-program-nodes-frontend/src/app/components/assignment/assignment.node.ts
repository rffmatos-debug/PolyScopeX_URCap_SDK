import {
    ProgramNode,
    Waypoint,
    TabInputModel,
    VARIABLE_VALUE_TYPES,
    VariableDeclaration,
    VariableReference,
} from '@universal-robots/contribution-api';

export enum WaypointType {
    Teach = 'teach',
    Expression = 'expression',
}

export interface SampleAssignmentNode extends ProgramNode {
    type: 'ur-sample-node-assignment';
    parameters: {
        // Node's currently selected/declared variable + the assigned value + the tapInput tap selection:
        variable: TabInputModel<VariableDeclaration | VariableReference>;

        // Additional properties related to the assigned value:
        valueType: (typeof VARIABLE_VALUE_TYPES)[number]; // The last known type of the assignment value. Used for validation - that the assigned value (tapInput component just returns a string) matches the type of the node's referenced variable.
        valueReference?: VariableReference; // If the assignment value is a variable reference, this holds that reference

        // Properties related to waypointing:
        waypoint?: Waypoint;
        waypointType: WaypointType;
    };
}
