import { ForceUnit, ProgramNode, ExpressionEditorValue, TimeUnit } from '@universal-robots/contribution-api';

export interface SampleToolForceNode extends ProgramNode {
    type: 'ur-sample-node-tool-force';
    parameters: {
        x: ToolForceAxisParameter;
        y: ToolForceAxisParameter;
        z: ToolForceAxisParameter;
        zeroSensor: ToolForceZeroSensorParameter;
        selectedFrame: ToolForceFrameParameter;
    };
}

export interface ToolForceAxisParameter {
    enabled: boolean;
    value: ExpressionEditorValue;
    unit: ForceUnit;
    variableName?: string;
}

export interface ToolForceZeroSensorParameter {
    enabled: boolean;
    value: ExpressionEditorValue;
    unit: TimeUnit;
    variableName?: string;
}

export interface ToolForceFrameParameter {
    value: ExpressionEditorValue;
    variableName?: string;
}
