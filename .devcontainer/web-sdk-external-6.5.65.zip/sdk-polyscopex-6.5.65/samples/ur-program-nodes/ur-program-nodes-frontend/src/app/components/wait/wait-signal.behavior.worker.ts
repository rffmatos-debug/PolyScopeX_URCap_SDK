import { firstValueFrom } from 'rxjs';
import {
    convertValue,
    Current,
    CurrentUnit,
    operatorInverseMap,
    ProgramBehaviorAPI,
    ProgramLabel,
    ScriptBuilder,
    Signal,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    VALIDATION_OK,
    Value,
    Voltage,
    VoltageUnit,
} from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { getAcceptableVariableTypes, isUnitOfDomain, validateSignalInput } from '../signal-helper';
import { getName, validateVariable } from '../variable-helper';
import { WaitTypeStrategy } from './wait-type-handler.interface';
import { SampleWaitNodeSignalInput } from './wait.node';

export const SignalInputStrategy: WaitTypeStrategy = {
    programNodeLabel: async (node): Promise<ProgramLabel> => {
        const signalInput = node.parameters.signalInput;

        if (!signalInput?.groupId || !signalInput?.signalID || !signalInput?.sourceID || signalInput.value === undefined) {
            return [{ type: 'primary', value: '' }];
        }

        const signalName = await getSignalName(signalInput.groupId, signalInput.sourceID, signalInput.signalID);

        if (signalInput.selectedType === SelectedInput.VARIABLE && node.parameters.reference?.valueReference) {
            const variableName = await getName(node.parameters.reference.valueReference);
            return buildVariableLabel(signalName, signalInput, variableName ?? '');
        }

        if (signalInput.signalValueType === SignalValueTypeEnum.BOOLEAN) {
            return buildBooleanLabel(signalName, signalInput.value as boolean);
        }

        if (signalInput.signalValueType === SignalValueTypeEnum.CUSTOM) {
            return buildCustomLabel(signalName, signalInput.value);
        }

        if (typeof signalInput.value === 'number' || typeof signalInput.value === 'string') {
            return buildNumericLabel(signalName, signalInput);
        }

        return buildAnalogLabel(signalName, signalInput);
    },

    validator: async (node) => {
        const signalInput = node.parameters.signalInput;
        const api = new ProgramBehaviorAPI(self);

        if (!signalInput?.sourceID || !signalInput?.signalID || signalInput?.value === undefined) {
            return { isValid: false };
        }

        // Legacy robot group validation (must be checked before generic validation)
        if (signalInput?.groupId === 'robot' && typeof signalInput.value === 'object') {
            const domains = await api.sourceService.getAnalogSignalDomains(signalInput.sourceID);
            const currentDomain = domains[signalInput.signalID];
            return { isValid: isUnitOfDomain(signalInput.value.unit as CurrentUnit | VoltageUnit, currentDomain) };
        }

        const signals = await api.sourceService.getSignals(signalInput.sourceID);
        const signal = signals.find((s) => s.signalID === signalInput.signalID);

        const signalValidation = validateSignalInput({
            signal,
            registerOperator: signalInput.registerOperator,
        });
        if (!signalValidation.isValid) {
            return signalValidation;
        }

        if (signalInput.selectedType === SelectedInput.VARIABLE && node.parameters.reference?.valueReference) {
            const acceptableTypes = getAcceptableVariableTypes(signalInput.signalValueType);
            return validateVariable(node.parameters.reference.valueReference, acceptableTypes);
        }

        if (signalInput.groupId) {
            return await api.sourceService.validateGetSignal(
                signalInput.groupId,
                signalInput.sourceID,
                signalInput.signalID,
                signalInput.value,
                '',
            );
        }

        return VALIDATION_OK;
    },

    generateCodeBeforeChildren: async (node) => {
        const builder = new ScriptBuilder();
        const signalInput = node.parameters.signalInput;

        if (!signalInput?.groupId || !signalInput?.sourceID || !signalInput.signalID || signalInput.value === undefined) {
            return builder;
        }

        const api = new ProgramBehaviorAPI(self);
        const signal = await findSignal(api, signalInput);

        if (!signal) {
            return builder;
        }

        const left = await api.sourceService.getGetSignalScript(signalInput.groupId, signalInput.sourceID, signalInput.signalID);
        const whileExpression = buildWhileExpression(left, signal, signalInput);

        if (whileExpression) {
            builder.beginWhile(whileExpression);
            builder.sync();
            builder.end();
        }

        return builder;
    },
};

async function getSignalName(groupId: string, sourceId: string, signalId: string): Promise<string> {
    const api = new ProgramBehaviorAPI(self);
    const signals = await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceId));
    const signal = signals.find((s: Signal) => s.signalID === signalId);
    return signal?.name ?? signalId;
}

async function findSignal(api: ProgramBehaviorAPI, signalInput: SampleWaitNodeSignalInput): Promise<Signal | undefined> {
    if (!signalInput.groupId || !signalInput.sourceID) {
        return undefined;
    }

    const signals = await firstValueFrom(
        api.sourceService.sourceSignals(signalInput.groupId, signalInput.sourceID, { direction: SignalDirectionEnum.IN }),
    );
    return signals.find((s) => s.signalID === signalInput.signalID);
}

function buildWhileExpression(left: string, signal: Signal, signalInput: SampleWaitNodeSignalInput): string {
    if (signalInput.value && signalInput.signalValueType === SignalValueTypeEnum.CUSTOM) {
        return `${left} != ${signalInput.value}`;
    }

    const expressionBuilders: Record<SignalValueTypeEnum, () => string> = {
        [SignalValueTypeEnum.BOOLEAN]: () => {
            const right = signalInput.value ? 'False' : 'True';
            return `${left} == ${right}`;
        },
        [SignalValueTypeEnum.REGISTER]: () => {
            const operator = signalInput?.registerOperator ?? '==';
            return `${left} ${operatorInverseMap[operator]} ${signalInput.value}`;
        },
        [SignalValueTypeEnum.FLOAT]: () => {
            if (!signalInput.floatOperator) return '';
            const right = getFloatValue(signalInput);
            return `${left} ${operatorInverseMap[signalInput.floatOperator]} ${right}`;
        },
        [SignalValueTypeEnum.CUSTOM]: () => '',
    };

    return expressionBuilders[signal.valueType]?.() ?? '';
}

function getFloatValue(signalInput: SampleWaitNodeSignalInput): number | string {
    const value = signalInput.value as Value | number | string;

    if (typeof value === 'object' && 'unit' in value) {
        if (value.unit === 'mA') {
            return convertValue<Current>(value as Current, 'A').value;
        }
        if (value.unit === 'V') {
            return (value as Voltage).value;
        }
    }

    return value as number | string;
}

function buildBooleanLabel(signalName: string, value: boolean): ProgramLabel {
    const hiLow = value ? 'high' : 'low';
    return [
        {
            type: 'primary',
            translationKey: 'program-node-label.single-value',
            interpolateParams: { value: signalName ? `${signalName} == ` : '' },
        },
        {
            type: 'secondary',
            translationKey: signalName ? `program-node-label.abbreviations.${hiLow}` : '',
        },
    ];
}

function buildCustomLabel(signalName: string, value: SampleWaitNodeSignalInput['value']): ProgramLabel {
    return [
        {
            type: 'primary',
            translationKey: 'program-node-label.single-value',
            interpolateParams: { value: signalName ? `${signalName} == ` : '' },
        },
        {
            type: 'secondary',
            translationKey: `program-node-label.abbreviations.custom-variable`,
            interpolateParams: { variableName: signalName ? `${value}` : '' },
        },
    ];
}

function buildVariableLabel(signalName: string, signalInput: SampleWaitNodeSignalInput, variableName: string): ProgramLabel {
    const operator = signalInput.registerOperator || signalInput.floatOperator || '==';
    return [
        { type: 'primary', value: signalName ? `${signalName} ${operator}` : '' },
        { type: 'secondary', value: variableName ? `Variable: ${variableName}` : '' },
    ];
}

function buildNumericLabel(signalName: string, signalInput: SampleWaitNodeSignalInput): ProgramLabel {
    const operator = signalInput.registerOperator || signalInput.floatOperator;
    return [
        { type: 'primary', value: signalName ? `${signalName} ${operator}` : '' },
        { type: 'secondary', value: signalName ? `${signalInput.value}` : '' },
    ];
}

function buildAnalogLabel(signalName: string, signalInput: SampleWaitNodeSignalInput): ProgramLabel {
    const input = signalInput.value as Current | Voltage;
    const operator = signalInput.floatOperator;
    return [
        { type: 'primary', value: `${signalName} ` },
        { type: 'secondary', value: `${operator} ${input.value} ${input.unit}` },
    ];
}
