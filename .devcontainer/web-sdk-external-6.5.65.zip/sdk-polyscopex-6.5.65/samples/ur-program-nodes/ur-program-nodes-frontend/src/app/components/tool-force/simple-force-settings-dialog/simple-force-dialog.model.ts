import { FrameName, ToolForceFrameParameter, ToolForceZeroSensorParameter } from '@universal-robots/contribution-api';

export interface SimpleForceDialogModel {
    zeroSensor: ToolForceZeroSensorParameter;
    selectedFrame: ToolForceFrameParameter;
    frames: FrameName[];
}
