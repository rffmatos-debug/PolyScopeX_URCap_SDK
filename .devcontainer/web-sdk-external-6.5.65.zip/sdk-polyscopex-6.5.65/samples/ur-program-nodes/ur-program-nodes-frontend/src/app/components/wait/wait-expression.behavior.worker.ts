import { ProgramBehaviorAPI, ScriptBuilder, VariableValueType } from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { WaitTypeStrategy } from './wait-type-handler.interface';

export const ExpressionStrategy: WaitTypeStrategy = {
    programNodeLabel: (node) => {
        const expression = node.parameters.expression;
        if (!expression?.value) {
            return [{ type: 'secondary', value: '' }];
        }
        return [{ type: 'secondary', value: `${expression.value}` }];
    },

    validator: async (node) => {
        const expression = node.parameters.expression;

        if (!expression?.value) {
            return { isValid: false };
        }

        if (expression.selectedType === SelectedInput.VARIABLE) {
            const api = new ProgramBehaviorAPI(self);
            const isValid = await api.symbolService.isValidVariable(expression.value.toString(), [
                VariableValueType.FLOAT,
                VariableValueType.INTEGER,
                VariableValueType.BOOLEAN,
            ]);
            if (!isValid) {
                return { isValid: false };
            }
        }

        return { isValid: true };
    },

    generateCodeBeforeChildren: async (node) => {
        const builder = new ScriptBuilder();
        const expression = node.parameters.expression;

        if (expression?.value) {
            const expr = expression.value.toString();
            builder.beginWhile(`not (${expr})`);
            builder.sync();
            builder.end();
        }

        return builder;
    },
};
