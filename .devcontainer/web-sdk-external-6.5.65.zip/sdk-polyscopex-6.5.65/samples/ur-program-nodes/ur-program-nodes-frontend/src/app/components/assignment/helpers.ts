import {
    ApplicationNodeType,
    GridPatternNode,
    GridPatternParameters,
    ProgramBehaviorAPI,
    ProgramPresenterAPI,
} from '@universal-robots/contribution-api';

export async function isValidGridPattern(name: string, api: ProgramBehaviorAPI | ProgramPresenterAPI): Promise<boolean> {
    const gridPatternNode = (await api.applicationService?.getApplicationNode(ApplicationNodeType.GRID_PATTERN)) as GridPatternNode;

    if (gridPatternNode) {
        const grid = gridPatternNode.grids.find((grid: GridPatternParameters) => grid.grid.name === name);
        if (grid && !validateGridPattern(grid)) {
            return false;
        }
    }

    // if the grid not found on the grid pattern application node, we assume the grid pattern is valid.
    return true;
}

function validateGridPattern(gridPattern: GridPatternParameters): boolean {
    // A grid pattern needs to have at least some corner positions defined.
    if (!gridPattern.corners.length) {
        return false;
    }

    // Determine whether the grid pattern is 1D (single row or column) or 2D (matrix).
    // 1D grids need at least 2 corners.
    // 2D grids need at least 4 corners.
    const columns = gridPattern.numColumns;
    const rows = gridPattern.numRows;
    const requiredCorners = columns === 1 || rows === 1 ? 2 : 4;

    const hasRequiredCorners = gridPattern.corners.length >= requiredCorners;

    // Every corner must be defined to be a valid grid.
    const hasValidCorners = gridPattern.corners.every((corner) => !!corner);

    return hasRequiredCorners && hasValidCorners;
}
