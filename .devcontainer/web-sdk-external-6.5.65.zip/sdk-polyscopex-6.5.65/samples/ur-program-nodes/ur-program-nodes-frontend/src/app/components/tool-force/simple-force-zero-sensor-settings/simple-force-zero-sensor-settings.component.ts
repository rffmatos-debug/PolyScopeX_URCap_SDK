import { ChangeDetectionStrategy, Component, EventEmitter, Input, Output } from '@angular/core';
import { ToolForceZeroSensorParameter } from '@universal-robots/contribution-api';

@Component({
    selector: 'ur-simple-force-zero-sensor-settings',
    templateUrl: './simple-force-zero-sensor-settings.component.html',
    styleUrls: ['./simple-force-zero-sensor-settings.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SimpleForceZeroSensorSettingsComponent {
    @Input() zeroSensor!: ToolForceZeroSensorParameter;
    @Output() zeroSensorSettingsChanged = new EventEmitter<ToolForceZeroSensorParameter>();

    setZeroSensorValue($event: number) {
        this.zeroSensor.value = $event;
        this.zeroSensorSettingsChanged.emit(this.zeroSensor);
    }

    setZeroSensorEnabledValue($event: boolean) {
        this.zeroSensor.enabled = $event;
        this.zeroSensorSettingsChanged.emit(this.zeroSensor);
    }
}
