import { ChangeDetectionStrategy, ChangeDetectorRef, Component, OnChanges, signal, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { firstValueFrom } from 'rxjs';
import {
    ApplicationNodeType,
    Frame,
    FramesNode,
    isExpression,
    isVariableReference,
    PositionAxes,
    PositionAxis,
    ProgramPresenterAPI,
    VariableDescriptionWithReference,
    VariableValueType,
} from '@universal-robots/contribution-api';
import { CloseReason, URValidatorFn } from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { SimpleForceDialogModel } from './simple-force-settings-dialog/simple-force-dialog.model';
import { SampleToolForceNode } from './tool-force.node';

@Component({
    templateUrl: './tool-force.component.html',
    styleUrls: ['./tool-force.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class ToolForceComponent extends CommonProgramPresenterComponent<SampleToolForceNode> implements OnChanges {
    maxToolForce!: number;
    axes = PositionAxes;
    variables: VariableDescriptionWithReference[] = [];

    validators: Array<URValidatorFn> = [];

    // Signals for local validation state
    axisValidation = signal<Record<PositionAxis, boolean>>({ x: true, y: true, z: true });
    frameValidation = signal<boolean>(true);

    constructor(
        protected readonly translateService: TranslateService,
        protected readonly cd: ChangeDetectorRef,
    ) {
        super(translateService, cd);
    }

    override onSetRobotSettings() {
        super.onSetRobotSettings();
        this.setValidators();
    }

    private setValidators() {
        this.validators = [
            (control) => {
                const value = Number(control.value);
                if (value > this.maxToolForce || value < -this.maxToolForce) {
                    return this.translateService.instant('presenter.tool-force.validation-error', { lim: this.maxToolForce });
                }
                return null;
            },
        ];
    }

    async fetchVariables() {
        if (!this.presenterAPI) {
            return [];
        }
        return await firstValueFrom(this.presenterAPI.variableService.variables());
    }

    async isValidFrame(frameId: string, api: ProgramPresenterAPI): Promise<boolean> {
        const frames = (await api.applicationService.getApplicationNode(ApplicationNodeType.FRAMES)) as FramesNode;
        return frames.framesList.some((frame) => frame.name === frameId);
    }

    async handleContributedNodeChanges(changes: SimpleChanges) {
        if (!(this.presenterAPI && this.contributedNode) || !(changes.contributedNode || changes.presenterAPI)) {
            return;
        }

        this.variables = await this.fetchVariables();

        const newAxisValidation = this.validateAxes();
        this.axisValidation.set(newAxisValidation);

        const frameName = this.extractFrameName();
        const isFrameValid = await this.isValidFrame(frameName, this.presenterAPI);
        this.frameValidation.set(isFrameValid);

        this.cd.detectChanges();
    }

    private validateAxes(): Record<PositionAxis, boolean> {
        const newAxisValidation = { ...this.axisValidation() };

        for (const axis of this.axes) {
            const parameter = this.contributedNode.parameters[axis];
            if (!parameter.enabled) {
                newAxisValidation[axis] = true;
                continue;
            }

            newAxisValidation[axis] = this.validateAxisParameter(parameter);
        }

        return newAxisValidation;
    }

    private validateAxisParameter(parameter: { value: unknown; variableName?: string }): boolean {
        if (isVariableReference(parameter.value)) {
            return this.validateVariableReference(parameter.value);
        }
        return String(parameter.value).length > 0;
    }

    private validateVariableReference(value: { id: string }): boolean {
        const variable = this.variables.find((v) => v.reference.id === value.id);
        return variable?.valueType === VariableValueType.FLOAT && !variable.programNodeMetadata?.isSuppressed;
    }

    private extractFrameName(): string {
        const frameValue = this.contributedNode.parameters.selectedFrame.value;
        if (isVariableReference(frameValue)) {
            return this.contributedNode.parameters.selectedFrame.variableName ?? '';
        }
        if (isExpression(frameValue)) {
            return frameValue.expression;
        }
        return String(frameValue);
    }
    async ngOnChanges(changes: SimpleChanges): Promise<void> {
        await super.ngOnChanges(changes);

        if (changes.presenterAPI && this.presenterAPI) {
            this.maxToolForce = await this.presenterAPI.safetyService.getMaxToolForce();
            this.cd.detectChanges();
        }

        this.handleContributedNodeChanges(changes);
    }

    toggle(axis: PositionAxis) {
        const toggledAxis = this.contributedNode.parameters[axis];
        toggledAxis.enabled = !toggledAxis.enabled;
        this.saveNode();
    }

    async openExpressionEditor(axis: PositionAxis) {
        if (!this.presenterAPI) {
            return;
        }
        const parameter = this.contributedNode.parameters[axis];
        const result = await this.presenterAPI.expressionEditorService.openExpressionEditor({
            label: this.getLabel(axis),
            expressionEditorValue: parameter.value,
            valueType: 'float',
            unit: parameter.unit,
            validators: this.validators,
            tabs: ['VALUE', 'VARIABLE', 'EXPRESSION'],
            keyboardLayout: 'numeric-free',
        });

        if (result) {
            parameter.value = result;

            if (isVariableReference(result)) {
                this.variables = await this.fetchVariables();
                const variable = this.variables.find((v) => v.reference.id === result.id);
                if (variable) {
                    parameter.variableName = variable.name;
                }
            } else {
                parameter.variableName = undefined;
            }

            this.saveNode();
        }
    }

    getValue(axis: PositionAxis): string {
        const parameter = this.contributedNode.parameters[axis];
        const value = parameter.value;

        if (isVariableReference(value)) {
            const variable = this.variables.find((v) => v.reference.id === value.id);
            return variable ? variable.name : (parameter.variableName ?? '');
        } else if (isExpression(value)) {
            return value.expression;
        } else {
            return String(value);
        }
    }

    getUnit(axis: PositionAxis): string {
        const parameter = this.contributedNode.parameters[axis];
        if (isVariableReference(parameter.value) || isExpression(parameter.value)) {
            return '';
        }
        return parameter.unit;
    }

    getLabel(axis: PositionAxis) {
        return `${axis.toUpperCase()}`;
    }

    public async openAdvancedSettingsDialog() {
        if (!this.presenterAPI) {
            return;
        }
        const dialogData = await this.presenterAPI.dialogService.openCustomDialog<SimpleForceDialogModel>(
            'ur-simple-force-settings-dialog',
            {
                ...this.contributedNode.parameters,
                zeroSensor: this.contributedNode.parameters.zeroSensor,
                selectedFrame: await this.getSelectedFrame(),
                frames: (await this.getFramesList()).map((frame) => frame.name),
            },
            {
                icon: 'access',
                title: this.translateService.instant('presenter.tool-force.label.more_settings'),
                dialogSize: 'LARGE',
                confirmText: this.translateService.instant('presenter.tool-force.label.confirm_text'),
                raiseForKeyboard: false,
            },
        );
        const { reason, returnData } = dialogData;
        if (reason !== CloseReason.CONFIRMED) {
            return;
        }

        if (returnData && Object.keys(returnData).length > 0) {
            this.contributedNode.parameters.zeroSensor = { ...returnData.zeroSensor };
            this.contributedNode.parameters.selectedFrame = { ...returnData.selectedFrame };
            this.saveNode();
        }
    }

    private async getSelectedFrame() {
        const selectedFrame = this.contributedNode.parameters.selectedFrame;
        // If value is empty, set default.
        // Assuming value is string for frame name.
        if (typeof selectedFrame.value === 'string' && !selectedFrame.value) {
            const frames = await this.getFramesList();
            if (frames.length > 0) {
                selectedFrame.value = frames[0].name;
            }
        }
        return selectedFrame;
    }

    private async getFramesList(): Promise<Frame[]> {
        if (!this.presenterAPI) {
            return [];
        }
        return ((await this.presenterAPI.applicationService.getApplicationNode(ApplicationNodeType.FRAMES)) as FramesNode).framesList;
    }
}
