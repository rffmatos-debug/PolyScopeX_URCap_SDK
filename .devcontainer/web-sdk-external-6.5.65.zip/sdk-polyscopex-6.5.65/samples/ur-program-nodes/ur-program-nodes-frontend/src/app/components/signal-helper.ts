import {
    CurrentUnit,
    CurrentUnits,
    registerOperator,
    Signal,
    SignalAnalogDomainValueEnum,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    ValidationResponse,
    VariableValueType,
    VoltageUnit,
    VoltageUnits,
} from '@universal-robots/contribution-api';
import { TabInputValueType } from '@universal-robots/ui-models';

/**
 * Configuration for signal input validation.
 */
export interface SignalInputConfig {
    signal?: Signal;
    registerOperator?: registerOperator;
}

const ALL_VARIABLE_TYPES = [VariableValueType.INTEGER, VariableValueType.FLOAT, VariableValueType.STRING, VariableValueType.BOOLEAN];

/**
 * Maps signal value types to acceptable variable value types for validation.
 */
const signalToVariableTypeMap: Record<SignalValueTypeEnum | 'DEFAULT', VariableValueType[]> = {
    [SignalValueTypeEnum.BOOLEAN]: [VariableValueType.BOOLEAN],
    [SignalValueTypeEnum.FLOAT]: [VariableValueType.INTEGER, VariableValueType.FLOAT],
    [SignalValueTypeEnum.REGISTER]: [VariableValueType.INTEGER, VariableValueType.FLOAT],
    [SignalValueTypeEnum.CUSTOM]: ALL_VARIABLE_TYPES,
    DEFAULT: ALL_VARIABLE_TYPES,
};

const SUPPORTED_SIGNAL_VALUE_TYPES = [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER];

/**
 * Returns the acceptable variable value types for a given signal value type.
 * Used for behavior validation.
 */
export const getAcceptableVariableTypes = (signalValueType: SignalValueTypeEnum | undefined): VariableValueType[] =>
    signalToVariableTypeMap[signalValueType ?? 'DEFAULT'] ?? signalToVariableTypeMap['DEFAULT'];

/**
 * Returns the acceptable tab input value types for a given signal value type.
 * Used for UI component filtering.
 */
export const getAcceptableTabInputTypes = (signalValueType: SignalValueTypeEnum | undefined): TabInputValueType[] =>
    getAcceptableVariableTypes(signalValueType).map((v) => v.toString() as TabInputValueType);

/**
 * Validates that the signal value type is supported.
 */
export const validateSignalValueType = (signalValueType: SignalValueTypeEnum): ValidationResponse =>
    SUPPORTED_SIGNAL_VALUE_TYPES.includes(signalValueType)
        ? { isValid: true }
        : { isValid: false, errorMessageKey: 'Signal type not supported' };

/**
 * Validates that the register operator is set when signal type is REGISTER.
 */
export const validateRegisterOperator = (signalValueType: SignalValueTypeEnum, registerOperator?: registerOperator): ValidationResponse =>
    signalValueType === SignalValueTypeEnum.REGISTER && registerOperator === undefined
        ? { isValid: false, errorMessageKey: 'register operator must be set' }
        : { isValid: true };

/**
 * Validates that the signal direction is IN.
 */
export const validateSignalDirection = (signalDirection: SignalDirectionEnum): ValidationResponse =>
    signalDirection === SignalDirectionEnum.IN ? { isValid: true } : { isValid: false, errorMessageKey: 'Signal must be an input signal' };

/**
 * Validates that the unit matches the domain (for legacy robot group).
 */
export const isUnitOfDomain = (unit: CurrentUnit | VoltageUnit, domain: SignalAnalogDomainValueEnum): boolean => {
    if ((CurrentUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.CURRENT) {
        return true;
    }
    return (VoltageUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.VOLTAGE;
};

/**
 * Validates signal input configuration.
 * Returns the first validation error encountered, or { isValid: true } if all validations pass.
 */
export const validateSignalInput = (config: SignalInputConfig): ValidationResponse => {
    if (!config.signal) {
        return { isValid: false, errorMessageKey: 'Signal not found' };
    }

    const signalTypeValidation = validateSignalValueType(config.signal.valueType);
    if (!signalTypeValidation.isValid) {
        return signalTypeValidation;
    }

    const registerOperatorValidation = validateRegisterOperator(config.signal.valueType, config.registerOperator);
    if (!registerOperatorValidation.isValid) {
        return registerOperatorValidation;
    }

    const directionValidation = validateSignalDirection(config.signal.direction);
    if (!directionValidation.isValid) {
        return directionValidation;
    }

    return { isValid: true };
};
