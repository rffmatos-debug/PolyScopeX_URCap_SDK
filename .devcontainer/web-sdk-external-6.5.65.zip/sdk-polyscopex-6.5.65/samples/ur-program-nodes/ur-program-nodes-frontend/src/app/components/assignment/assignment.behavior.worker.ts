/// <reference lib="webworker" />
import {
    isVariableDeclaration,
    isVariableReference,
    isWaypoint,
    KinematicPosition,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    TabInputModel,
    URVariable,
    ValidationResponse,
    VARIABLE_VALUE_TYPES,
    VariableDeclaration,
    VariableReference,
    VariableService,
    VariableValueType,
    Waypoint,
    WaypointType,
} from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { getName, getType, getVariableDescription, isRegistered, validateVariable } from '../variable-helper';
import { SampleAssignmentNode } from './assignment.node';
import { isValidGridPattern } from './helpers';

const behaviors: ProgramBehaviors<SampleAssignmentNode> = {
    allowedInLogicProgram: () => true,
    programNodeLabel,
    factory,
    generateCodeBeforeChildren,
    validator,
    upgradeNode,
};

async function programNodeLabel(node: SampleAssignmentNode): Promise<ProgramLabel> {
    const [variableName, variableType] = await Promise.all([
        getName(node.parameters.variable.entity),
        getType(node.parameters.variable.entity),
    ]);

    if (variableType === VariableValueType.WAYPOINT && node.parameters.waypointType === WaypointType.Teach) {
        return [
            {
                type: 'primary',
                translationKey: 'program-node-label.assignment.waypoint',
            },
            {
                type: 'secondary',
                translationKey: 'program-node-label.single-value',
                interpolateParams: { value: `${variableName ?? ''}` },
            },
        ];
    }

    let value = node.parameters.variable.value;
    // If value is a variable reference, get the variable's name:
    if (node.parameters.variable.selectedType === 'VARIABLE' && node.parameters.valueReference) {
        const valueVariable = await getVariableDescription(node.parameters.valueReference);
        value = valueVariable?.name ?? value;
    }

    return [
        {
            type: 'primary',
            value: `${variableName ?? ''}:`,
        },
        {
            type: 'secondary',
            value: `${value}`,
        },
    ];
}

async function factory(): Promise<SampleAssignmentNode> {
    const variable: VariableDeclaration = await new ProgramBehaviorAPI(self).variableService.createVariable(
        'var',
        VariableValueType.INTEGER,
    );

    return {
        type: 'ur-sample-node-assignment',
        version: '0.0.3',
        allowsChildren: false,
        parameters: {
            variable: new TabInputModel<VariableDeclaration>(variable, 'VALUE', 0),
            valueType: 'integer',
            waypointType: WaypointType.Teach,
        },
    };
}

async function validator(node: SampleAssignmentNode): Promise<ValidationResponse> {
    if (!(await isRegistered(node.parameters.variable.entity as VariableReference))) {
        return { isValid: false, errorMessageKey: 'Variable does not exist' };
    }

    const referencedVariable = await getVariableDescription(node.parameters.variable.entity as VariableReference);

    if (node.parameters.valueType !== referencedVariable?.valueType) {
        return { isValid: false, errorMessageKey: 'Variable type mismatch' };
    }

    if (
        node.parameters.variable.selectedType === 'VARIABLE' &&
        referencedVariable?.valueType === 'grid' &&
        !(await isValidGridPattern(node.parameters.variable.value.toString(), new ProgramBehaviorAPI(self)))
    ) {
        return { isValid: false, errorMessageKey: 'Invalid grid pattern' };
    }

    if (!isDefinedTeachedWaypoint(node) && isValueUndefinedOrEmpty(node.parameters.variable)) {
        return { isValid: false, errorMessageKey: 'Missing value' };
    }

    if (isDefinedTeachedWaypoint(node) && !isWaypoint(node.parameters.waypoint)) {
        return { isValid: false, errorMessageKey: 'Invalid waypoint' };
    }

    if (referencedVariable?.programNodeMetadata?.isSuppressed) {
        return { isValid: false, errorMessageKey: 'Variable is suppressed' };
    }

    if (node.parameters.variable.selectedType === 'VARIABLE' && node.parameters.valueReference && referencedVariable?.valueType) {
        const valueValidation = await validateVariable(node.parameters.valueReference, [referencedVariable.valueType]);
        if (!valueValidation.isValid) {
            return valueValidation;
        }
    }

    return { isValid: true };
}

async function generateCodeBeforeChildren(node: SampleAssignmentNode): Promise<ScriptBuilder> {
    const builder: ScriptBuilder = new ScriptBuilder();
    const variable = node.parameters.variable.entity;
    const value = node.parameters.variable.value.toString();
    const waypoint = node.parameters.waypoint;
    let expression: string;

    if ((await isWaypointAndTeach(node)) && waypoint) {
        // TODO: create struct expression
    } else {
        expression = value;
    }

    const variableName = await getName(variable);
    if (isVariableReference(variable) && variableName) {
        builder.assign(variableName, expression);
    } else if (isVariableDeclaration(variable) && variable.name) {
        builder.globalVariable(variable.name, expression);
    }

    return builder;
}

async function isWaypointAndTeach(node: SampleAssignmentNode) {
    const type = await getType(node.parameters.variable.entity);

    return type === VariableValueType.WAYPOINT && node.parameters.waypointType === WaypointType.Teach;
}

async function upgradeNode(node: unknown): Promise<SampleAssignmentNode> {
    node = upgradeNodeTo001(node);
    node = await upgradeNodeTo002(node);
    node = await upgradeNodeTo003(node);
    return node as SampleAssignmentNode;
}

registerProgramBehavior(behaviors);

type v001node = Omit<SampleAssignmentNode, 'parameters'> & {
    parameters: {
        waypointOptions?: 'edit' | 'set';
        isValid?: boolean;
        variable: URVariable;
        isNewVariable: boolean;
        expression: string;
        tabInputExpression: TabInputModel<string>;
        waypointParameters?: {
            waypointSource: WaypointType;
            position?: KinematicPosition;
        };
    };
};
type v002node = Omit<SampleAssignmentNode, 'parameters'> & {
    parameters: {
        variable: TabInputModel<URVariable>;
        waypoint?: Waypoint;
        waypointType: WaypointType;
    };
};
type v003node = Omit<SampleAssignmentNode, 'parameters'> & {
    parameters: {
        variable: TabInputModel<VariableDeclaration | VariableReference>;
        valueType: (typeof VARIABLE_VALUE_TYPES)[number]; // The selected variable's value type. Used for validation of values that are themselves variable references.
        waypoint?: Waypoint;
        waypointType: WaypointType;
    };
};
async function upgradeNodeTo003(node: unknown): Promise<v003node | unknown> {
    if ((node as any)?.version !== '0.0.2') {
        return node;
    }
    const oldNode = node as v002node;
    const newNode = structuredClone(node) as v003node;

    newNode.version = '0.0.3';

    // Convert URVariable -> VariableDeclaration | VariableReference:
    const variableService = new VariableService(self);
    const upgradedVariable: VariableDeclaration | VariableReference | undefined = await variableService.upgradeURVariable(
        oldNode.parameters.variable.entity,
    );
    newNode.parameters.variable = {
        ...oldNode.parameters.variable,
        entity: upgradedVariable ?? { id: 'N/A', _IDENTIFIER: 'VariableReference' },
    };
    newNode.parameters.valueType = (await getType(newNode.parameters.variable.entity)) ?? 'string';

    return newNode as v003node;
}

async function upgradeNodeTo002(node: unknown): Promise<v002node | unknown> {
    const oldNode = node as any;
    if (oldNode?.version !== '0.0.1') {
        return node;
    }

    const newNode = structuredClone(node) as v002node;
    // clear the old parameters
    newNode.parameters = {} as any;

    let variable: TabInputModel<URVariable>;
    const oldParams = oldNode.parameters;
    if (
        oldParams.variable?.valueType === 'float' ||
        oldParams.variable?.valueType === 'integer' ||
        oldParams.variable?.valueType === 'string'
    ) {
        variable = new TabInputModel<URVariable>(
            oldParams.variable,
            oldParams.tabInputExpression.selectedType,
            oldParams.tabInputExpression.value,
        );
    } else {
        variable = new TabInputModel<URVariable>(oldParams.variable, 'EXPRESSION', oldNode.parameters.expression);
    }

    variable.entity.valueType = oldParams.variable?.reference
        ? (await getVariableDescription(oldParams.variable.name))?.valueType
        : oldParams.variable.valueType;
    newNode.parameters.variable = variable;

    //if the type was waypoint and the waypoint was taught
    if (
        oldParams.variable.valueType === VariableValueType.WAYPOINT &&
        oldParams.waypointParameters?.waypointSource === 'teach' &&
        oldParams.waypointParameters?.position
    ) {
        // TODO upgrade waypoint model
    }
    newNode.parameters.waypointType = oldParams.waypointParameters?.waypointSource || WaypointType.Teach;

    newNode.version = '0.0.2';
    return newNode as v002node;
}

function upgradeNodeTo001(node: unknown): v001node | unknown {
    if ((node as any)?.version) {
        return node;
    }
    const loadedNode = structuredClone(node) as any;
    loadedNode.version = '0.0.1';
    if (!loadedNode.parameters.tabInputExpression) {
        loadedNode.parameters = {
            ...loadedNode.parameters,
            tabInputExpression: {
                entity: '',
                selectedType: SelectedInput.VALUE,
                value: '',
            },
        };
    }
    if (
        'expression' in loadedNode.parameters &&
        !loadedNode.parameters.tabInputExpression?.value &&
        (loadedNode.parameters.variable?.valueType === VariableValueType.STRING ||
            loadedNode.parameters.variable?.valueType === VariableValueType.INTEGER ||
            loadedNode.parameters.variable?.valueType === VariableValueType.FLOAT)
    ) {
        loadedNode.parameters = {
            ...loadedNode.parameters,
            tabInputExpression: {
                entity: '',
                selectedType: 'VALUE',
                value: loadedNode.parameters.expression,
            },
        };
    }
    if (
        loadedNode.parameters.tabInputExpression?.value !== '' &&
        loadedNode.parameters.expression === '' &&
        loadedNode.parameters.variable?.valueType !== VariableValueType.STRING &&
        loadedNode.parameters.variable?.valueType !== VariableValueType.INTEGER &&
        loadedNode.parameters.variable?.valueType !== VariableValueType.FLOAT
    ) {
        loadedNode.parameters = {
            ...loadedNode.parameters,
            expression: loadedNode.parameters.tabInputExpression.value.toString(),
        };
    }
    return loadedNode as v001node;
}

function isValueUndefinedOrEmpty(variable: TabInputModel<VariableReference | VariableDeclaration>) {
    if (typeof variable.value === 'number') {
        return false;
    }
    if (typeof variable.value === 'string') {
        return variable.value.toString().length === 0;
    }
    return true;
}

function isDefinedTeachedWaypoint(node: SampleAssignmentNode) {
    return node.parameters.valueType === 'waypoint' && node.parameters.waypointType === WaypointType.Teach;
}
