import { ChangeDetectionStrategy, Component, EventEmitter, Input, OnInit, Output, signal } from '@angular/core';
import {
    isExpression,
    isVariableReference,
    ToolForceFrameParameter,
    ToolForceZeroSensorParameter,
} from '@universal-robots/contribution-api';
import { WebComponentDialogComponent } from '@universal-robots/contribution-api/angular';
import { SimpleForceDialogModel } from './simple-force-dialog.model';

@Component({
    templateUrl: './simple-force-settings-dialog.component.html',
    styleUrls: ['./simple-force-settings-dialog.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SimpleForceSettingsDialogComponent
    implements WebComponentDialogComponent<SimpleForceDialogModel, SimpleForceDialogModel>, OnInit
{
    @Input() inputData!: SimpleForceDialogModel;
    @Output() outputDataChange = new EventEmitter<SimpleForceDialogModel>();
    @Output() canSave = new EventEmitter<boolean>();

    activeTab = 'reference';
    referenceLabel = signal<string>('');
    zeroSensorLabel = signal<string>('');

    ngOnInit() {
        this.outputDataChange.emit(this.inputData);
        this.zeroSensorLabel.set(this.getZeroSensorLabel());
        this.referenceLabel.set(this.getReferenceLabel());
    }

    onLinkChanged(event: string) {
        this.activeTab = event;
    }

    onZeroSensorSettingsChanged($event: ToolForceZeroSensorParameter) {
        this.inputData.zeroSensor = $event;
        this.zeroSensorLabel.set(this.getZeroSensorLabel());
        this.outputDataChange.emit(this.inputData);
    }

    onSelectedFrameChanged($event: ToolForceFrameParameter) {
        this.inputData.selectedFrame = $event;
        this.referenceLabel.set(this.getReferenceLabel());
        this.outputDataChange.emit(this.inputData);
    }

    getZeroSensorLabel() {
        if (!this.inputData.zeroSensor.enabled) {
            return '';
        }
        const val = this.inputData.zeroSensor.value;
        const name = this.inputData.zeroSensor.variableName;
        const strVal = this.getValueAsString(val, name);
        return `${strVal} sec`;
    }

    getReferenceLabel() {
        const val = this.inputData.selectedFrame.value;
        const name = this.inputData.selectedFrame.variableName;
        const strVal = this.getValueAsString(val, name);
        return strVal ?? '';
    }

    private getValueAsString(val: unknown, name?: string): string {
        if (isVariableReference(val)) {
            return name ?? '';
        }
        if (isExpression(val)) {
            return val.expression;
        }
        if (val === null || val === undefined) {
            return '';
        }
        return String(val);
    }
}
