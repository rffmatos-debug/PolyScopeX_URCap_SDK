import { ChangeDetectionStrategy, Component, computed, inject, Signal, signal } from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { combineLatest, filter, map, Observable, switchMap, tap, withLatestFrom } from 'rxjs';
import {
    isVariableReference,
    isWaypoint,
    MoveScreenOptions,
    ProgramPresenterAPI,
    VARIABLE_VALUE_TYPES,
    VariableDeclaration,
    VariableDescriptionWithReference,
    VariableReference,
    WaypointType,
} from '@universal-robots/contribution-api';
import {
    DropdownOption,
    InputValidator,
    SelectedInput,
    SelectedType,
    TabInputInsertableModel,
    TabInputValue,
} from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { getVariableNameValidator } from '../validator-helper';
import { SampleAssignmentNode } from './assignment.node';
import { isValidGridPattern } from './helpers';

@Component({
    templateUrl: './assignment.component.html',
    styleUrls: ['./assignment.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class AssignmentComponent extends CommonProgramPresenterComponent<SampleAssignmentNode> {
    readonly translateService = inject(TranslateService);

    private node$ = toObservable(this.node).pipe(filter((node) => node !== undefined));
    private api$ = toObservable(this.api).pipe(filter((api) => api !== undefined));
    private settings$ = toObservable(this.settings).pipe(filter((settings) => settings !== undefined));
    private variables$ = this.api$.pipe(
        switchMap((api) => api.variableService.variables()),
        map((variables) => variables.filter((variable) => variable.valueType !== 'frame' && variable.valueType !== 'profile')),
    );
    private variables: Signal<VariableDescriptionWithReference[]> = toSignal(this.variables$, { initialValue: [] });
    private nodeVariable$: Observable<VariableDescriptionWithReference> = combineLatest([
        this.node$,
        this.api$,
        this.variables$.pipe(filter((variables) => variables.length > 1)),
    ]).pipe(
        switchMap(([node, api]) => api.variableService.getVariableDescription(node.parameters.variable.entity as VariableReference)),
        filter((variable) => !!variable),
    );

    /*
     * Variable selection/creation:
     */
    public variableOptions: Signal<DropdownOption[]> = toSignal(
        this.variables$.pipe(
            map((variables) =>
                variables.map((variable) => {
                    return {
                        label: variable.name,
                        value: variable.name,
                        invalid: variable.programNodeMetadata?.isSuppressed,
                    };
                }),
            ),
        ),

        { initialValue: [] },
    );
    public variableNameValidator: InputValidator<string> = getVariableNameValidator.bind(this)();
    public variableDropdown = signal<{ label: string; icon: string }>({
        label: this.translateService.instant('presenter.assignment.variable_dropdown.new'),
        icon: 'pencil',
    });
    public nodeVariable: Signal<VariableDescriptionWithReference | undefined> = toSignal(this.nodeVariable$);

    public async createVariable(varName: string) {
        if (this.api() === undefined) {
            return;
        }

        if (this.contributedNode.parameters.variable.entity._IDENTIFIER === 'VariableDeclaration') {
            this.contributedNode.parameters.variable.entity.name = varName;
            this.saveNode();
            return;
        }

        const newVariable: VariableDeclaration | undefined = await this.api()?.variableService.createVariable(
            varName,
            this.nodeVariable()?.valueType ?? 'string',
        );

        if (newVariable) {
            this.contributedNode.parameters.variable.entity = newVariable;
            this.saveNode();
        }
    }

    public variableDropdownOpen() {
        this.variableDropdown.set(
            isVariableReference(this.contributedNode.parameters.variable.entity)
                ? { label: this.translateService.instant('presenter.assignment.variable_dropdown.new'), icon: 'plus' }
                : { label: this.translateService.instant('presenter.assignment.variable_dropdown.rename'), icon: 'pencil' },
        );
    }

    public async selectVariable(variableOption: DropdownOption) {
        if (variableOption.label === this.nodeVariable()?.name) {
            return;
        }

        const selectedVariable: VariableDescriptionWithReference | undefined = this.variables().find(
            (variable) => variable.name === variableOption.label,
        );
        if (!selectedVariable) {
            return;
        }

        this.contributedNode.parameters.variable.entity = { ...selectedVariable.reference };
        this.contributedNode.parameters.valueType = selectedVariable.valueType;

        if (selectedVariable?.valueType === 'waypoint') {
            this.contributedNode.parameters.waypointType = WaypointType.Teach;
        }
        this.saveNode();
    }

    /*
     * Value type selection:
     * Set by user if variable is a declaration, otherwise read-only, inherited from the referenced variable.
     */
    public variableTypeTranslationFactory = (variableType: string) => this.translateService.instant('variable-type.' + variableType);
    public variableValueTypes = Object.values(VARIABLE_VALUE_TYPES)
        .filter((val) => val !== 'frame' && val !== 'profile')
        .sort((a, b) => a.localeCompare(b));
    public isVariableReference = isVariableReference;

    /**
     * For variable declarations, sets
     * - the valueType
     * - resets the value and selectedType (selected tapInput tap type) accordingly
     * - updates the last known valueType of the node, for validation purposes
     * - if waypoint, sets waypointType to Teach
     * */
    public setType(valueType: (typeof VARIABLE_VALUE_TYPES)[number]) {
        let newValue: string | number = '';
        let newSelectedInput: SelectedType = SelectedInput.VALUE; // selected tapInput type/tap

        if (valueType === 'float' || valueType === 'integer') {
            newValue = 0;
        }

        const currentValue = this.tabInputValue();
        if (currentValue?.selectedType === SelectedInput.EXPRESSION) {
            newValue = currentValue.value;
            newSelectedInput = SelectedInput.EXPRESSION;
        }

        if (valueType === 'waypoint') {
            this.contributedNode.parameters.waypointType = WaypointType.Teach;
        }

        (this.contributedNode.parameters.variable.entity as VariableDeclaration).valueType = valueType;
        this.contributedNode.parameters.variable.selectedType = newSelectedInput;
        this.contributedNode.parameters.variable.value = newValue;
        this.contributedNode.parameters.valueType = valueType;

        this.saveNode();
    }

    /*
     * Value input, general:
     */
    // All variables, excluding this node's variable:
    public filteredVariables: Signal<VariableDescriptionWithReference[]> = toSignal(
        combineLatest([this.node$.pipe(map((node) => node.parameters.variable.entity)), this.api$, this.variables$]).pipe(
            switchMap(async ([nodeVariable, api, variables]) => {
                const variableDescription = await api.variableService.getVariableDescription(nodeVariable as VariableReference);

                return variables.filter((variable) => variable.name !== variableDescription?.name);
            }),
        ),
        { initialValue: [] },
    );
    public expressionInsertables: Signal<TabInputInsertableModel> = toSignal(
        this.api$.pipe(switchMap((api) => api.expressionEditorService.getTabInputInsertableModel())),
        { initialValue: { functions: [], variables: [], inputs: [], outputs: [], builtins: [] } },
    );
    public tabInputValueTabValidators: Signal<Array<InputValidator>> = toSignal(
        combineLatest([this.node$, this.settings$]).pipe(
            map(() => [
                (input) => {
                    if ((input as string).length === 0) {
                        return this.translateService.instant('presenter.assignment.empty_expression_error');
                    }
                    return null;
                },
                (input) => {
                    if (this.nodeVariable()?.valueType === 'integer' && !Number.isInteger(Number(input))) {
                        return this.translateService.instant('presenter.assignment.integer_error');
                    }
                    return null;
                },
            ]),
        ),
        { initialValue: [] },
    );
    public tabInputValue: Signal<TabInputValue | undefined> = toSignal(
        this.node$.pipe(
            map((node) => node.parameters.variable),
            map((nodeVariable) => {
                return {
                    value: nodeVariable.value,
                    selectedType: nodeVariable.selectedType,
                };
            }),
        ),
    );
    public precision = computed(() => {
        const variable = this.nodeVariable();
        if (variable?.valueType === 'integer') return 0;
        if (variable?.valueType === 'float') return 10;
        return null;
    });
    public isTapInputValid = toSignal(
        this.nodeVariable$.pipe(
            withLatestFrom(this.api$),
            switchMap(([nodeVariable, api]) => this.isValueValid(this.contributedNode, nodeVariable, api)),
        ),
        { initialValue: true },
    );

    public tabInputValueChanged(input: TabInputValue) {
        const nodeVariable = this.contributedNode.parameters.variable;

        nodeVariable.selectedType = input.selectedType;

        if (nodeVariable.selectedType === 'VALUE') {
            switch (this.nodeVariable()?.valueType) {
                case 'integer':
                    nodeVariable.value = parseInt(input.value as string, 10);
                    break;
                case 'float':
                    nodeVariable.value = parseFloat(input.value as string);
                    break;
                default:
                    nodeVariable.value = String(input.value);
            }
        }

        if (nodeVariable.selectedType === 'VARIABLE') {
            const referencedVariable = this.filteredVariables().find((variable) => variable.name === String(input.value));

            if (!referencedVariable) {
                return;
            }

            nodeVariable.value = referencedVariable.name;
            this.contributedNode.parameters.valueReference = { ...referencedVariable.reference };
        }

        if (nodeVariable.selectedType === 'EXPRESSION') {
            nodeVariable.value = String(input.value);
        }

        this.contributedNode.parameters.valueType = this.nodeVariable()?.valueType ?? 'string';

        this.saveNode();
    }

    /**
     * Keeps the assigned value updated, if it is a variable reference.
     */
    private valueVariableEffect = toSignal(
        combineLatest([this.node$, this.variables$]).pipe(
            tap(([node, variables]) => {
                if (node.parameters.variable.selectedType === SelectedInput.VARIABLE) {
                    // The assigned value is a variable reference, update the value (displayed variable name) if it changed.
                    const valueVariable = variables.find(
                        (variable) => variable.reference.id === String(node.parameters.valueReference?.id),
                    );

                    if (valueVariable && valueVariable.name !== this.contributedNode.parameters.variable.value) {
                        this.contributedNode.parameters.valueReference = { ...valueVariable.reference };
                        this.contributedNode.parameters.variable.value = valueVariable.name;
                        this.saveNode();
                    }
                }
            }),
        ),
    );

    /*
     * Value input, waypoint:
     */
    public selectedWaypointSource: Signal<(DropdownOption & { value: WaypointType }) | undefined> = toSignal(
        this.node$.pipe(
            map((node) => this.wayPointSources.find((source) => source.value === node.parameters.waypointType)),
            filter((dropdownOption) => !!dropdownOption),
            map((dropdownOption) => {
                return { value: this.contributedNode.parameters.waypointType, label: dropdownOption.label };
            }),
        ),
    );
    public wayPointSources: DropdownOption[] = [
        {
            label: this.translateService.instant('presenter.assignment.label.teach'),
            value: WaypointType.Teach,
        },
        {
            label: this.translateService.instant('presenter.assignment.label.set_expression'),
            value: WaypointType.Expression,
        },
    ];

    public setWaypointSource(value: WaypointType) {
        this.contributedNode.parameters.waypointType = value;
        this.saveNode();
    }

    public async openMoveScreen() {
        const variableName = this.nodeVariable()?.name;

        if (!variableName || this.api() === undefined) {
            return;
        }

        window.parent.performance.mark('setWaypointStart');
        const storedWaypoint = this.contributedNode.parameters.waypoint;
        const options: MoveScreenOptions = {
            moveScreenTarget: 'waypoint',
            moveScreenTargetLabel: variableName,
            frame: storedWaypoint?.frame,
            tcp: storedWaypoint?.tcp,
            position: isWaypoint(storedWaypoint) ? storedWaypoint : undefined,
        };
        const newWaypoint = await this.api()?.robotMoveService.openMoveScreen(options);

        if (isWaypoint(newWaypoint)) {
            this.contributedNode.parameters.waypoint = newWaypoint;
            this.saveNode();
        }
    }

    /*
     * -- PRIVATE --
     */
    private async isValueValid(
        node: SampleAssignmentNode,
        nodeVariableReference: VariableDescriptionWithReference | undefined,
        api: ProgramPresenterAPI,
    ): Promise<boolean> {
        if (!nodeVariableReference) {
            return false;
        }

        // No value?
        if (node.parameters.variable.value.toString().length === 0) {
            return false;
        }

        if (node.parameters.variable.selectedType === SelectedInput.VARIABLE) {
            // Value is a reference to another variable.
            const valueVariable = this.variables().find(
                (variable) => variable.reference?.id === String(node.parameters.valueReference?.id),
            );

            // Is the variable registered?
            if (!valueVariable) {
                return false;
            }

            if (valueVariable.programNodeMetadata?.isSuppressed) {
                return false;
            }

            // Does the value's type match the node's type?
            if (valueVariable.valueType !== nodeVariableReference.valueType) {
                return false;
            }

            // Is valid Grid pattern?
            if (
                nodeVariableReference?.valueType === 'grid' &&
                !(await isValidGridPattern(node.parameters.variable.value.toString(), api))
            ) {
                return false;
            }
        }

        // Does the last known type of the node match the currently selected variable's valueType?
        if (node.parameters.valueType !== nodeVariableReference.valueType) {
            return false;
        }

        return true;
    }
}
