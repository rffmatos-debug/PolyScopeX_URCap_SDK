import { ChangeDetectionStrategy, ChangeDetectorRef, Component, Input, OnChanges, OnDestroy, signal, SimpleChanges } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { asyncScheduler, combineLatest, firstValueFrom, Subject, Subscription } from 'rxjs';
import { tap, throttleTime } from 'rxjs/operators';
import {
    Acceleration,
    AccelerationUnit,
    Angle,
    AngleUnit,
    AngularAcceleration,
    AngularAccelerationUnit,
    AngularSpeed,
    AngularSpeedUnit,
    convertValue,
    Length,
    LengthUnit,
    Mass,
    MassUnit,
    ProgramNode,
    ProgramPresenter,
    ProgramPresenterAPI,
    RobotSettings,
    Speed,
    SpeedUnit,
    Time,
    TimeUnit,
} from '@universal-robots/contribution-api';
import * as fromValidatorHelper from './validator-helper';

const THROTTLE_TIME = 500;
const THROTTLE_CONFIG = {
    leading: true,
    trailing: true,
};

interface ValueConstraints {
    lowerLimit: number;
    upperLimit: number;
    unit: string;
}

@Component({
    template: '',
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class CommonProgramPresenterComponent<T extends ProgramNode = ProgramNode> implements ProgramPresenter, OnChanges, OnDestroy {
    readonly api = signal<ProgramPresenterAPI | undefined>(undefined);
    readonly node = signal<T | undefined>(undefined);
    readonly settings = signal<RobotSettings | undefined>(undefined);

    @Input() presenterAPI: ProgramPresenterAPI | undefined;

    private readonly changesSubject = new Subject<ProgramNode>();
    private readonly presenterAPISubject = new Subject<ProgramPresenterAPI>();
    private readonly subscriptions$ = new Subscription();

    constructor(
        protected readonly translateService: TranslateService,
        protected readonly cd: ChangeDetectorRef,
    ) {
        this.subscriptions$.add(
            combineLatest([this.changesSubject, this.presenterAPISubject])
                .pipe(
                    throttleTime(THROTTLE_TIME, asyncScheduler, THROTTLE_CONFIG),
                    tap(async ([node, api]) => {
                        await api.programNodeService.updateNode(node);
                    }),
                )
                .subscribe(),
        );
    }

    async ngOnChanges(changes: SimpleChanges): Promise<void> {
        if (this.presenterAPI && changes.contributedNode?.isFirstChange()) {
            this.presenterAPI.logPerformanceService.logPerformanceMetrics(`load${changes.contributedNode.currentValue?.type}`);
            this.presenterAPI.logPerformanceService.logPerformanceMetrics(`add${changes.contributedNode.currentValue?.type}`);
        }
        if (changes.presenterAPI) {
            this.presenterAPISubject.next(changes.presenterAPI.currentValue);

            this.api.set(changes.presenterAPI.currentValue);
        }
        if (changes.contributedNode) {
            this.onSetContributedNode();

            this.node.set(changes.contributedNode.currentValue);

            this.cd.detectChanges();
        }

        if (changes.robotSettings?.isFirstChange()) {
            this.translateService.setDefaultLang('en');
        }

        if (changes.robotSettings) {
            this.settings.set(changes.robotSettings.currentValue);

            await firstValueFrom(this.translateService.use(changes.robotSettings.currentValue.language));
            this.onSetRobotSettings();
        }
    }

    ngOnDestroy(): void {
        this.subscriptions$.unsubscribe();
    }

    @Input() contributedNode!: T;

    onSetContributedNode(): void {
        // Override this method if you have local variables that derive state from the contributed node
        // It is important to do it here, as well as the init, otherwise features like undo/redo won't work correctly
    }

    @Input() robotSettings!: RobotSettings;

    onSetRobotSettings() {
        // Override this method if you have instantly translated values that need to change when language changes
        // It is important to do it here, as well as the init, otherwise features like undo/redo won't work correctly
    }

    public saveNode() {
        this.changesSubject.next(this.contributedNode);
    }

    // Using Mass object as this function will usually be called with a dataModel value
    convertValueFromSIMass(mass: Mass) {
        if (this.robotSettings.units.MASS) {
            return convertValue<Mass>(mass, this.robotSettings.units.MASS.label as MassUnit).value;
        }
        return 0;
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSIMass(mass: number) {
        return convertValue<Mass>({ value: mass, unit: this.robotSettings.units.MASS.label as MassUnit }, 'kg').value;
    }

    // Using Length object as this function will usually be called with a dataModel value
    convertValueFromSILength(length: Length) {
        if (this.robotSettings.units.LENGTH) {
            return convertValue<Length>(length, this.robotSettings.units.LENGTH.label as LengthUnit).value;
        }
        return 0;
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSILength(length: number) {
        return convertValue<Length>({ value: length, unit: this.robotSettings.units.LENGTH.label as LengthUnit }, 'm').value;
    }

    // Using Angle object as this function will usually be called with a dataModel value
    convertValueFromSIAngle(angle: Angle) {
        if (this.robotSettings.units.PLANE_ANGLE) {
            return convertValue<Angle>(angle, this.robotSettings.units.PLANE_ANGLE.label as AngleUnit).value;
        }
        return 0;
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSIAngle(angle: number) {
        return convertValue<Angle>({ value: angle, unit: this.robotSettings.units.PLANE_ANGLE.label as AngleUnit }, 'rad').value;
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSISpeed(speed: number) {
        return convertValue<Speed>({ value: speed, unit: this.robotSettings.units.SPEED.label as SpeedUnit }, 'm/s');
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSIAngularSpeed(speed: number) {
        return convertValue<AngularSpeed>(
            { value: speed, unit: this.robotSettings.units.ANGULAR_SPEED.label as AngularSpeedUnit },
            'rad/s',
        );
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSIAcceleration(acceleration: number) {
        return convertValue<Acceleration>(
            { value: acceleration, unit: this.robotSettings.units.ACCELERATION.label as AccelerationUnit },
            'm/s^2',
        );
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSIAngularAngularAcceleration(acceleration: number) {
        return convertValue<AngularAcceleration>(
            { value: acceleration, unit: this.robotSettings.units.ANGULAR_ACCELERATION.label as AngularAccelerationUnit },
            'rad/s^2',
        );
    }

    // Using number as this function will usually be called with an input field value
    convertValueToSITime(time: number) {
        return convertValue<Time>({ value: time, unit: this.robotSettings.units.TIME.label as TimeUnit }, 's');
    }

    getRangeErrorString(val: number, constraints: ValueConstraints): string | null {
        return fromValidatorHelper.getRangeErrorString(val, constraints, this.robotSettings.units, this.translateService);
    }
}
