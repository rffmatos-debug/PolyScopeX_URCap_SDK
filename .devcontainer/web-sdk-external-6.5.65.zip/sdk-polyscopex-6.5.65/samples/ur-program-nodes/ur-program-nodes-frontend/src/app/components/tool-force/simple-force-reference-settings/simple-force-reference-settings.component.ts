import { ChangeDetectionStrategy, Component, computed, EventEmitter, input, Output } from '@angular/core';
import { FrameName, ToolForceFrameParameter } from '@universal-robots/contribution-api';

@Component({
    selector: 'ur-simple-force-reference-settings',
    templateUrl: './simple-force-reference-settings.component.html',
    styleUrls: ['./simple-force-reference-settings.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SimpleForceReferenceSettingsComponent {
    @Output() selectedFrameChanged = new EventEmitter<ToolForceFrameParameter>();
    selectedFrame = input.required<ToolForceFrameParameter>();
    frames = input.required<FrameName[]>();
    selectedFrameDropdown = computed(() => {
        const savedFrame = this.selectedFrame().value as string;
        return this.frames().find((frame) => frame === savedFrame) ?? { label: savedFrame, invalid: true };
    });

    public setFrame(frameName: FrameName) {
        const frame: ToolForceFrameParameter = { ...this.selectedFrame() };
        frame.value = frameName;
        this.selectedFrameChanged.emit(frame);
    }
}
