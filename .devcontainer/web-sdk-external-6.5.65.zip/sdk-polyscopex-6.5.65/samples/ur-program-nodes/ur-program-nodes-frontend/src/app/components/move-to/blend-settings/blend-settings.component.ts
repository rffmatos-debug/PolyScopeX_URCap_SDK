import { Component, EventEmitter, input, Input, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Length, LengthUnits, MoveToBlendSettings, TabInputModel, URVariable } from '@universal-robots/contribution-api';
import { DropdownOption, TabInputInsertableModel, TabInputValue } from '@universal-robots/ui-models';
import { Units } from '@universal-robots/utilities-units';
import { getConvertedTabInputValueWithUnit, setConvertedTabInputValueWithUnit } from '../../tabinput-helper';
import { getRangeErrorString } from '../../validator-helper';

@Component({
    selector: 'ur-blend-settings',
    templateUrl: './blend-settings.component.html',
    styleUrls: ['./blend-settings.component.scss'],
    standalone: false,
})
export class BlendSettingsComponent {
    @Input({ required: true })
    blendSettings!: MoveToBlendSettings;

    @Input({ required: true })
    units!: Units;

    @Input({ required: true })
    variables!: URVariable[];

    insertables = input.required<TabInputInsertableModel>();

    @Output()
    blendSettingsChanged = new EventEmitter<MoveToBlendSettings>();

    blendOptions: DropdownOption[];

    constructor(private readonly translateService: TranslateService) {
        this.blendOptions = [
            {
                value: 'false',
                label: this.translateService.instant('presenter.move-to.blend.disabled'),
            },
            {
                value: 'true',
                label: this.translateService.instant('presenter.move-to.blend.enabled'),
            },
        ];
    }

    setBlendEnabled($event: 'true' | 'false') {
        this.blendSettings.enabled = $event === 'true';
        if (this.blendSettings.enabled) {
            this.blendSettings.radius = new TabInputModel<Length>({ value: 0.05, unit: 'm' }, 'VALUE', 0.05);
        } else {
            delete this.blendSettings.radius;
        }
        this.blendSettingsChanged.emit(this.blendSettings);
    }

    getRadius() {
        if (!this.blendSettings.radius) {
            return;
        }
        return getConvertedTabInputValueWithUnit(this.blendSettings.radius, this.units.LENGTH);
    }

    setRadius($event: TabInputValue) {
        if (!this.blendSettings.radius) {
            return;
        }
        setConvertedTabInputValueWithUnit(this.blendSettings.radius, $event, this.units.LENGTH, LengthUnits[0]);
        this.blendSettingsChanged.emit(this.blendSettings);
    }

    blendValidator = (val: number): string | null => {
        return getRangeErrorString(val, { unit: 'm', lowerLimit: 0, upperLimit: 1 }, this.units, this.translateService);
    };
}
