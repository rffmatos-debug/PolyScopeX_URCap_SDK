import { ProgramBehaviors } from '@universal-robots/contribution-api';
import { SampleWaitNode } from './wait.node';

export type WaitTypeStrategy = Required<
    Pick<ProgramBehaviors<SampleWaitNode>, 'programNodeLabel' | 'validator' | 'generateCodeBeforeChildren'>
>;
