import { ProgramNode, SignalValue, SignalValueTypeEnum, VARIABLE_VALUE_TYPES, VariableReference } from '@universal-robots/contribution-api';
import { SelectedType } from '@universal-robots/ui-models';

export interface SampleSetNodeVariableReference {
    valueType: (typeof VARIABLE_VALUE_TYPES)[number];
    valueReference: VariableReference;
}

export interface SampleSetNode extends ProgramNode {
    type: 'ur-sample-node-set';
    parameters: {
        signalOutput?: {
            groupId?: string;
            sourceID?: string;
            signalID?: string;
            selectedType?: SelectedType;
            value?: SignalValue;
            signalValueType?: SignalValueTypeEnum;
        };
        reference?: SampleSetNodeVariableReference;
    };
}
