/// <reference lib="webworker" />
import {
    AdvancedTranslatedProgramLabel,
    ApplicationNodeType,
    ExpressionEditorValue,
    FramesNode,
    isExpression,
    isVariableReference,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    ValidationResponse,
} from '@universal-robots/contribution-api';
import { SampleToolForceNode } from './tool-force.node';

const behaviors: ProgramBehaviors<SampleToolForceNode> = {
    factory: (): SampleToolForceNode => {
        return {
            type: 'ur-sample-node-tool-force',
            version: '0.0.4',
            allowsChildren: true,
            parameters: {
                x: {
                    enabled: false,
                    value: 0,
                    unit: 'N',
                },
                y: {
                    enabled: false,
                    value: 0,
                    unit: 'N',
                },
                z: {
                    enabled: false,
                    value: 0,
                    unit: 'N',
                },
                zeroSensor: {
                    enabled: true,
                    value: 0.02,
                    unit: 's',
                },
                selectedFrame: {
                    value: 'base',
                },
            },
        };
    },

    programNodeLabel: async (node: SampleToolForceNode): Promise<ProgramLabel> => {
        const programNodeLabels: AdvancedTranslatedProgramLabel = [];
        const api = new ProgramBehaviorAPI(self);

        // Helper to get script value (which returns variable name if reference)
        const getScript = async (value: ExpressionEditorValue) => {
            return await api.expressionEditorService.getScript(value);
        };

        const axes = [
            { name: 'X', ...node.parameters.x },
            { name: 'Y', ...node.parameters.y },
            { name: 'Z', ...node.parameters.z },
        ];

        for (const axis of axes) {
            if (axis.enabled) {
                const value = await getScript(axis.value);
                const unit = !isVariableReference(axis.value) && !isExpression(axis.value) ? axis.unit : '';

                programNodeLabels.push({
                    type: 'secondary',
                    translationKey: 'program-node-label.single-value',
                    interpolateParams: { value: `${axis.name}: ${value} ${unit}` },
                });
            }
        }

        if (node.parameters.zeroSensor?.enabled) {
            const time = await getScript(node.parameters.zeroSensor.value);
            const Unit = node.parameters.zeroSensor.unit;

            programNodeLabels.push({
                type: 'secondary',
                translationKey: 'presenter.tool-force.label.zero-sensor',
            });
            programNodeLabels.push({
                type: 'secondary',
                translationKey: 'program-node-label.single-value',
                interpolateParams: { value: `${time} ${Unit}` },
            });
        }

        const frameName = await getScript(node.parameters.selectedFrame.value);
        programNodeLabels.push({
            type: 'secondary',
            translationKey: 'presenter.tool-force.label.reference',
        });
        programNodeLabels.push({
            type: 'secondary',
            translationKey: 'program-node-label.single-value',
            interpolateParams: { value: frameName },
        });

        return programNodeLabels;
    },
    validator: async (node, context): Promise<ValidationResponse> => {
        // Force node must have at least one child to be valid
        let notSuppressedNodesCount = 0;
        for await (const child of context.traverse.children) {
            if (!child.isSuppressed) {
                notSuppressedNodesCount++;
            }
        }
        if (notSuppressedNodesCount === 0) {
            return {
                isValid: false,
                errorMessageKey: 'Tool force has no nodes',
            };
        }

        const x = { name: 'X', ...node?.parameters?.x };
        const y = { name: 'Y', ...node?.parameters?.y };
        const z = { name: 'Z', ...node?.parameters?.z };

        const api = new ProgramBehaviorAPI(self);

        if (!node.parameters) {
            return { isValid: false };
        }
        const enabledNodes = [x, y, z].filter((item) => item.enabled);

        if (enabledNodes.length === 0) {
            return { isValid: false }; // At least one axis must be enabled
        }

        //For of is needed because of the async await.
        for (const axis of enabledNodes) {
            if (isVariableReference(axis.value)) {
                const variable = await api.variableService.getVariableDescription(axis.value);

                if (!variable || variable.valueType !== 'float' || variable.programNodeMetadata?.isSuppressed) {
                    return { isValid: false };
                }
            } else if (isExpression(axis.value)) {
                if (!axis.value.expression || axis.value.expression.trim() === '') {
                    return { isValid: false };
                }
            } else {
                if (axis.value === '') {
                    return { isValid: false };
                }
                const val = Number(axis.value);
                if (isNaN(val)) {
                    return { isValid: false };
                }
            }
        }

        // Zero Sensor Validation
        if (node.parameters.zeroSensor.enabled) {
            const zeroSensorValue = node.parameters.zeroSensor.value;
            if (isVariableReference(zeroSensorValue)) {
                const variable = await api.variableService.getVariableDescription(zeroSensorValue);
                if (!variable || variable.valueType !== 'float' || variable.programNodeMetadata?.isSuppressed) {
                    return { isValid: false };
                }
            } else if (typeof zeroSensorValue === 'number') {
                if (zeroSensorValue < 0) {
                    return {
                        isValid: false,
                        errorMessageKey: 'Waiting value should not be negative',
                    };
                }
            } else if (isExpression(zeroSensorValue)) {
                if (!zeroSensorValue.expression || zeroSensorValue.expression.trim() === '') {
                    return { isValid: false };
                }
            }
        }

        // Frame Validation
        const frameName = await api.expressionEditorService.getScript(node.parameters.selectedFrame.value);

        let rawFrameName = frameName;
        if (!isVariableReference(node.parameters.selectedFrame.value) && !isExpression(node.parameters.selectedFrame.value)) {
            rawFrameName = String(node.parameters.selectedFrame.value);
        }

        const frameExists = await isValidFrame(rawFrameName, api);
        if (!frameExists) {
            return { isValid: false };
        }

        return { isValid: true };
    },
    generateCodeBeforeChildren: async (node: SampleToolForceNode): Promise<ScriptBuilder> => {
        const builder = new ScriptBuilder();
        const api = new ProgramBehaviorAPI(self);

        const { x, y, z, zeroSensor, selectedFrame } = node.parameters;
        if (![x, y, z].some((axis) => axis.enabled)) {
            return builder;
        }

        const getScript = async (value: ExpressionEditorValue) => {
            return await api.expressionEditorService.getScript(value);
        };

        const zeroSensorValue = await getScript(zeroSensor.value);

        let shouldZero = false;
        if (zeroSensor.enabled) {
            if (typeof zeroSensor.value === 'number') {
                shouldZero = zeroSensor.value >= 0;
            } else {
                shouldZero = true;
            }
        }

        if (shouldZero) {
            builder.sleep(zeroSensorValue);
            builder.addStatements('zero_ftsensor()');
        }

        // 1 or 0 to enable [x, y, z, rx, ry, rz]
        const selectionVector = `[${[x, y, z].map((axis) => (axis.enabled ? 1 : 0)).join(', ')}, 0, 0, 0]`;

        // Force in N [x, y, z, rx, ry, rz]
        // We need to await all getScript calls
        const xVal = await getScript(x.value);
        const yVal = await getScript(y.value);
        const zVal = await getScript(z.value);

        const wrench = `[${xVal}, ${yVal}, ${zVal}, 0.0, 0.0, 0.0]`;

        // don't transform the force frame
        const forceType = 2;

        // max motion in mm/s [x, y, z, rx, ry, rz]
        const limits = '[0.15, 0.15, 0.15, 0.3, 0.3, 0.3]';

        const taskFrameName = await getScript(selectedFrame.value);

        // Always quote the frame name for get_pose
        const quotedFrame = !/^".*"$/.test(taskFrameName) ? `"${taskFrameName}"` : taskFrameName;
        const taskFrame = `get_pose(${quotedFrame})`;
        const enableForceMode = `force_mode(${taskFrame}, ${selectionVector}, ${wrench}, ${forceType}, ${limits})`;

        builder.addStatements(enableForceMode);

        return builder;
    },
    generateCodeAfterChildren,
    upgradeNode: async (loadedNode: SampleToolForceNode): Promise<SampleToolForceNode> => {
        let oldNode = { ...loadedNode } as any;

        if (!loadedNode?.version) {
            oldNode = upgradeTo001(loadedNode, oldNode);
        }

        if (oldNode.version === '0.0.1') {
            oldNode = upgradeTo002(oldNode);
        }

        if (oldNode.version === '0.0.2') {
            oldNode = upgradeTo003(oldNode);
        }

        if (oldNode.version === '0.0.3') {
            oldNode = await upgradeTo004(oldNode);
        }

        return oldNode;
    },
};

function upgradeTo001(loadedNode: SampleToolForceNode, oldNode: any) {
    return {
        ...loadedNode,
        version: '0.0.1',
        parameters: {
            ...loadedNode.parameters,
            x: {
                isValid: !!oldNode.parameters.x.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.x.force,
                        },
                        enabled: oldNode.parameters.x.enabled,
                    },
                    selectedType: 'VALUE',
                    value: oldNode.parameters.x.force?.value,
                },
            },
            y: {
                isValid: !!oldNode.parameters.y.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.y.force,
                        },
                        enabled: oldNode.parameters.y.enabled,
                    },
                    selectedType: 'VALUE',
                    value: oldNode.parameters.y.force?.value,
                },
            },
            z: {
                isValid: !!oldNode.parameters.z.force,
                model: {
                    entity: {
                        force: {
                            ...oldNode.parameters.z.force,
                        },
                        enabled: oldNode.parameters.z.enabled,
                    },
                    selectedType: 'VALUE',
                    value: oldNode.parameters.z.force?.value,
                },
            },
        },
    };
}

function upgradeTo002(loadedNode: SampleToolForceNode) {
    const node = loadedNode as any;

    return {
        ...node,
        version: '0.0.2',
        parameters: {
            ...node.parameters,
            zeroSensor: {
                isValid: false,
                model: {
                    entity: { waiting: { value: 0.02, unit: 's' }, enabled: false },
                    selectedType: 'VALUE',
                    value: 0.02,
                },
            },
            selectedFrame: {
                isValid: true,
                model: {
                    entity: { frameName: 'tcp', enabled: false },
                    selectedType: 'VALUE',
                    value: 'tcp',
                },
            },
        },
    };
}

function upgradeTo003(loadedNode: SampleToolForceNode) {
    const node = loadedNode as any;
    node.version = '0.0.3';
    const { x, y, z } = node.parameters;
    [x, y, z].forEach((axis: any) => {
        if (axis.model.value === undefined) {
            axis.model.entity.force = { value: 0, unit: 'N' };
            axis.model.value = 0;
            axis.model.selectedType = 'VALUE';
        } else if (axis.model.entity?.force?.value === undefined) {
            axis.model.entity.force = { value: 0, unit: 'N' };
        }
    });

    return node;
}

async function upgradeTo004(loadedNode: SampleToolForceNode) {
    const node = loadedNode as any;
    node.version = '0.0.4';

    const api = new ProgramBehaviorAPI(self);

    // Helper to upgrade variable using symbolService.upgradeURVariable
    // We construct a temporary object that mimics URVariable for upgradeURVariable
    const resolveVariable = async (name: string): Promise<{ value: ExpressionEditorValue; variableName?: string }> => {
        // Construct a legacy-like object. upgradeURVariable expects URVariable structure.
        // URVariable has name, type, reference.
        // We set reference=true to get a VariableReference/Description back.
        const legacyVar = { name, type: '$$Variable', reference: true };

        const upgraded = await api.variableService.upgradeURVariable(legacyVar as any);

        if (upgraded && isVariableReference(upgraded)) {
            const desc = await api.variableService.getVariableDescription(upgraded);
            return {
                value: upgraded,
                variableName: desc?.name,
            };
        }
        return {
            value: { _IDENTIFIER: 'Expression', expression: name },
            variableName: undefined,
        };
    };

    const convertAxis = async (axis: any) => {
        const model = axis.model;
        let value: ExpressionEditorValue = model.value;
        let variableName: string | undefined = undefined;

        if (model.selectedType === 'VARIABLE') {
            const resolved = await resolveVariable(model.value as string);
            value = resolved.value;
            variableName = resolved.variableName;
        } else if (model.selectedType === 'EXPRESSION') {
            value = { _IDENTIFIER: 'Expression', expression: model.value as string };
        }

        return {
            enabled: model.entity.enabled,
            value: value,
            unit: model.entity.force?.unit ?? 'N',
            variableName: variableName,
        };
    };

    const convertZeroSensor = async (param: any) => {
        const model = param.model;
        let value: ExpressionEditorValue = model.value;
        let variableName: string | undefined = undefined;

        if (model.selectedType === 'VARIABLE') {
            const resolved = await resolveVariable(model.value as string);
            value = resolved.value;
            variableName = resolved.variableName;
        } else if (model.selectedType === 'EXPRESSION') {
            value = { _IDENTIFIER: 'Expression', expression: model.value as string };
        }

        return {
            enabled: model.entity.enabled,
            value: value,
            unit: model.entity.waiting?.unit ?? 's',
            variableName,
        };
    };

    const convertFrame = async (param: any) => {
        const model = param.model;
        let value: ExpressionEditorValue = model.value; // frameName
        let variableName: string | undefined = undefined;

        // Frames in TabInput were usually just values (strings) or variables.
        if (model.selectedType === 'VARIABLE') {
            const resolved = await resolveVariable(model.value as string);
            value = resolved.value;
            variableName = resolved.variableName;
        } else if (model.selectedType === 'EXPRESSION') {
            value = { _IDENTIFIER: 'Expression', expression: model.value as string };
        }

        return {
            value: value,
            variableName,
        };
    };

    node.parameters.x = await convertAxis(node.parameters.x);
    node.parameters.y = await convertAxis(node.parameters.y);
    node.parameters.z = await convertAxis(node.parameters.z);
    node.parameters.zeroSensor = await convertZeroSensor(node.parameters.zeroSensor);
    node.parameters.selectedFrame = await convertFrame(node.parameters.selectedFrame);

    return node;
}

function generateCodeAfterChildren(node: SampleToolForceNode): ScriptBuilder {
    const builder = new ScriptBuilder();

    const { x, y, z } = node.parameters;
    if ([x, y, z].some((axis) => axis.enabled)) {
        builder.addStatements('end_force_mode()');
        builder.addStatements('stopl(5.0)');
    }

    return builder;
}

async function isValidFrame(frameId: string, api: ProgramBehaviorAPI): Promise<boolean> {
    try {
        const frames = (await api.applicationService.getApplicationNode(ApplicationNodeType.FRAMES)) as FramesNode;
        if (!frames || !Array.isArray(frames.framesList)) return false;
        return frames.framesList.some((frame) => frame.name === frameId);
    } catch (e) {
        return false;
    }
}

registerProgramBehavior(behaviors);
