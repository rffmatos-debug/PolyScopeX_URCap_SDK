/// <reference lib="webworker" />
import { firstValueFrom } from 'rxjs';
import {
    Current,
    floatOperator,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    SignalValueTypeEnum,
    TabInputModel,
    Time,
    ValidationResponse,
    Voltage,
} from '@universal-robots/contribution-api';
import { SelectedInput } from '@universal-robots/ui-models';
import { lookupByName } from '../variable-helper';
import { ExpressionStrategy } from './wait-expression.behavior.worker';
import { SignalInputStrategy } from './wait-signal.behavior.worker';
import { TimeStrategy } from './wait-time.behavior.worker';
import { WaitTypeStrategy } from './wait-type-handler.interface';
import { SampleWaitNode, SampleWaitNodeSignalInput, SampleWaitNodeVariableReference } from './wait.node';

type WaitType = NonNullable<SampleWaitNode['parameters']['type']>;

const waitTypeStrategies: Record<WaitType, WaitTypeStrategy> = {
    time: TimeStrategy,
    signalInput: SignalInputStrategy,
    expression: ExpressionStrategy,
};

const behaviors: ProgramBehaviors<SampleWaitNode> = {
    allowedInLogicProgram: () => true,
    programNodeLabel: async (node: SampleWaitNode): Promise<ProgramLabel> => {
        return waitTypeStrategies[node.parameters.type].programNodeLabel(node);
    },
    factory: async (): Promise<SampleWaitNode> => {
        const time = new TabInputModel<Time>({ value: 1, unit: 's' }, SelectedInput.VALUE, 1);
        return {
            type: 'ur-sample-node-wait',
            version: '0.0.4',
            parameters: {
                type: 'time',
                time,
                signalInput: undefined,
                expression: undefined,
                reference: undefined,
            },
        };
    },

    validator: async (node: SampleWaitNode, context, applicationContext): Promise<ValidationResponse> => {
        return waitTypeStrategies[node.parameters.type].validator(node, context, applicationContext);
    },

    generateCodeBeforeChildren: async (node: SampleWaitNode, context, applicationContext): Promise<ScriptBuilder> => {
        return waitTypeStrategies[node.parameters.type].generateCodeBeforeChildren(node, context, applicationContext);
    },

    upgradeNode: async (node: SampleWaitNode): Promise<SampleWaitNode> => {
        let upgradedNode = structuredClone(node);
        upgradedNode = upgradeTo001(upgradedNode);
        upgradedNode = await upgradeTo002(upgradedNode);
        upgradedNode = await upgradeTo003(upgradedNode);
        upgradedNode = await upgradeTo004(upgradedNode);
        return upgradedNode;
    },
};

registerProgramBehavior(behaviors);

// ============================================================================
// Upgrade Functions
// ============================================================================
function upgradeTo001(node: SampleWaitNode): SampleWaitNode {
    if (node.version) {
        return node;
    }
    node.version = '0.0.1';
    return node;
}

async function upgradeTo002(upgradeable: SampleWaitNode): Promise<SampleWaitNode> {
    if (upgradeable.version !== '0.0.1') {
        return upgradeable;
    }

    const node = await upgradeSourceIds(upgradeable);
    node.version = '0.0.2';

    if (node.parameters.type !== 'signalInput' || !node.parameters.signalInput) {
        return node;
    }

    const signalInput = node.parameters.signalInput as SampleWaitNodeSignalInput & { analogOperator?: floatOperator };
    const { sourceID, signalID, value } = signalInput;

    if (!signalInput.groupId && sourceID && (sourceID === 'ur-tool-io' || sourceID === 'ur-wired-io')) {
        signalInput.groupId = 'robot';
    }
    if (signalInput?.analogOperator) {
        signalInput.floatOperator = signalInput.analogOperator;
        delete (node as any).parameters.signalInput.analogOperator;
    }

    if (signalInput.groupId && sourceID && signalID) {
        const api = new ProgramBehaviorAPI(self);
        const signals = await firstValueFrom(api.sourceService.sourceSignals(signalInput.groupId, sourceID));
        const signalValueType = signals?.find((s) => s.signalID === signalID)?.valueType;

        if (isValidSignalValue(signalValueType, value)) {
            signalInput.signalValueType = signalValueType;
        }
    }

    return node;
}

async function upgradeSourceIds(node: SampleWaitNode): Promise<SampleWaitNode> {
    const signalInput = node.parameters.signalInput;
    if (signalInput?.groupId === 'robot') {
        signalInput.groupId = 'ur-robot-io';
        if (signalInput?.sourceID === 'ur-wired-io') {
            signalInput.sourceID = 'ur-robot-wired-io';
        }
        if (signalInput?.sourceID === 'ur-tool-io') {
            signalInput.sourceID = 'ur-robot-tool-io';
        }
    }

    return node;
}

function isValidSignalValue(signalValueType: SignalValueTypeEnum | undefined, value: SampleWaitNodeSignalInput['value']): boolean {
    if (!signalValueType) return false;

    const validators: Record<SignalValueTypeEnum, () => boolean> = {
        [SignalValueTypeEnum.FLOAT]: () => !!(value as Current | Voltage)?.value || typeof value === 'number',
        [SignalValueTypeEnum.BOOLEAN]: () => typeof value === 'boolean',
        [SignalValueTypeEnum.REGISTER]: () => typeof value === 'number' && parseInt(value.toString()) === value,
        [SignalValueTypeEnum.CUSTOM]: () => false,
    };

    return validators[signalValueType]?.() ?? false;
}

async function upgradeTo003(node: SampleWaitNode): Promise<SampleWaitNode> {
    if (node.version !== '0.0.2') {
        return node;
    }
    node.version = '0.0.3';
    return await upgradeSourceIds(node);
}

async function upgradeVariableReference(variableName: string | undefined): Promise<SampleWaitNodeVariableReference | undefined> {
    if (!variableName) {
        return undefined;
    }
    const matchingVariable = await lookupByName(variableName);
    if (!matchingVariable) {
        return undefined;
    }
    return {
        valueType: matchingVariable.valueType,
        valueReference: matchingVariable.reference,
    };
}

async function upgradeTo004(node: SampleWaitNode): Promise<SampleWaitNode> {
    if (node.version !== '0.0.3') {
        return node;
    }
    node.version = '0.0.4';

    if (node.parameters.type === 'time' && node.parameters.time?.selectedType === 'VARIABLE') {
        node.parameters.reference = await upgradeVariableReference(node.parameters.time?.value?.toString());
    }
    if (node.parameters.type === 'signalInput' && node.parameters.signalInput?.selectedType === 'VARIABLE') {
        node.parameters.reference = await upgradeVariableReference(node.parameters.signalInput?.value?.toString());
    }
    return node;
}
