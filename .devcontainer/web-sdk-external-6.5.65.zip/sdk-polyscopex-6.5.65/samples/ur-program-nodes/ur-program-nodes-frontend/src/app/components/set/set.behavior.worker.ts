/// <reference lib="webworker" />
import { firstValueFrom } from 'rxjs';
import {
    ApplicationContext,
    Current,
    CurrentUnit,
    CurrentUnits,
    ProgramBehaviorAPI,
    ProgramBehaviors,
    ProgramLabel,
    registerProgramBehavior,
    ScriptBuilder,
    ScriptContext,
    Signal,
    SignalAnalogDomainValueEnum,
    SignalDirectionEnum,
    SignalValueTypeEnum,
    ValidationResponse,
    VariableValueType,
    Voltage,
    VoltageUnit,
    VoltageUnits,
} from '@universal-robots/contribution-api';
import { getName, lookupByName, validateVariable } from '../variable-helper';
import { SampleSetNode, SampleSetNodeVariableReference } from './set.node';

const behaviors: ProgramBehaviors<SampleSetNode> = {
    allowedInLogicProgram,
    factory,
    programNodeLabel,
    validator,
    generateCodeBeforeChildren,
    upgradeNode,
};

function allowedInLogicProgram(): boolean {
    return true;
}

async function factory(): Promise<SampleSetNode> {
    return {
        type: 'ur-sample-node-set',
        version: '0.0.5',
        allowsChildren: false,
        parameters: {
            signalOutput: {},
            reference: undefined,
        },
    };
}

async function programNodeLabel(node: SampleSetNode): Promise<ProgramLabel> {
    if (node.parameters.signalOutput) {
        return await generateSignalOutputLabel(node.parameters.signalOutput, node.parameters.reference);
    }
    return [{ type: 'primary', translationKey: 'program-node-label.default' }];
}

async function validator(
    node: SampleSetNode,
    context?: ScriptContext,
    applicationContext?: ApplicationContext,
): Promise<ValidationResponse> {
    const signalOutput = node.parameters.signalOutput;

    if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID) {
        return { isValid: false, errorMessageKey: 'Signal is undefined' };
    }

    if (signalOutput.value === undefined && signalOutput.selectedType !== 'VARIABLE') {
        return { isValid: false, errorMessageKey: 'Signal is undefined' };
    }
    let value = signalOutput.value ?? '';
    const api = new ProgramBehaviorAPI(self);

    // Legacy robot group validation (must be checked before generic validation)
    if (signalOutput?.groupId === 'robot' && typeof signalOutput.value === 'object' && 'unit' in signalOutput.value) {
        const domains = await api.sourceService.getAnalogSignalDomains(signalOutput.sourceID);
        const currentDomain = domains[signalOutput.signalID];
        return { isValid: isUnitOfDomain(signalOutput.value.unit as VoltageUnit | CurrentUnit, currentDomain) };
    }

    // Validate variable reference using new variable system
    if (
        signalOutput.selectedType === 'VARIABLE' &&
        signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM &&
        node.parameters.reference
    ) {
        const validation = await validateVariable(node.parameters.reference.valueReference, [VariableValueType.BOOLEAN]);
        if (!validation.isValid) {
            return validation;
        }
    }

    // Validate variable reference for float signals
    if (
        signalOutput.selectedType === 'VARIABLE' &&
        signalOutput.signalValueType === SignalValueTypeEnum.FLOAT &&
        node.parameters.reference
    ) {
        const validation = await validateVariable(node.parameters.reference.valueReference, [
            VariableValueType.FLOAT,
            VariableValueType.INTEGER,
        ]);
        if (!validation.isValid) {
            return validation;
        }
        value = (await getName(node.parameters.reference.valueReference)) ?? value;
    }

    // Validate variable reference for register signals
    if (
        signalOutput.selectedType === 'VARIABLE' &&
        signalOutput.signalValueType === SignalValueTypeEnum.REGISTER &&
        node.parameters.reference
    ) {
        const validation = await validateVariable(node.parameters.reference.valueReference, [
            VariableValueType.FLOAT,
            VariableValueType.INTEGER,
        ]);
        if (!validation.isValid) {
            return validation;
        }
        value = (await getName(node.parameters.reference.valueReference)) ?? value;
    }

    const validationResponse = await api.sourceService.validateSetSignal(
        signalOutput.groupId,
        signalOutput.sourceID,
        signalOutput.signalID,
        value,
    );
    if (!validationResponse.isValid) {
        return validationResponse;
    }

    return await validateSignal(signalOutput, api);
}

async function generateCodeBeforeChildren(
    node: SampleSetNode,
    context?: ScriptContext,
    applicationContext?: ApplicationContext,
): Promise<ScriptBuilder> {
    const api = new ProgramBehaviorAPI(self);
    const signalOutput = node.parameters.signalOutput;
    const builder = new ScriptBuilder();

    if (!signalOutput?.groupId || !signalOutput?.sourceID || !signalOutput.signalID) {
        return builder;
    }

    if (signalOutput.value === undefined && signalOutput.selectedType !== 'VARIABLE') {
        return builder;
    }

    let valueToUse = signalOutput.value ?? '';

    // When using a variable reference, get the actual variable name
    if (signalOutput.selectedType === 'VARIABLE' && node.parameters.reference?.valueReference) {
        const variableName = await getName(node.parameters.reference.valueReference);
        if (variableName) {
            valueToUse = variableName;
        }
    }

    const script = await api.sourceService.getSetSignalScript(
        signalOutput.groupId,
        signalOutput.sourceID,
        signalOutput.signalID,
        valueToUse,
    );
    builder.addRaw(script);
    return builder;
}

async function upgradeNode(node: SampleSetNode): Promise<SampleSetNode> {
    let upgradedNode = structuredClone(node);
    upgradedNode = upgradeTo001(upgradedNode);
    upgradedNode = await upgradeTo002(upgradedNode);
    upgradedNode = await upgradeTo003(upgradedNode);
    upgradedNode = await upgradeTo004(upgradedNode);
    upgradedNode = await upgradeTo005(upgradedNode);
    return upgradedNode;
}

registerProgramBehavior(behaviors);

/** Builds the "signal = variableName" label when the value is a variable reference (CUSTOM, FLOAT, or REGISTER). */
async function buildVariableReferenceLabel(
    signalOutput: SampleSetNode['parameters']['signalOutput'],
    reference: SampleSetNode['parameters']['reference'] | undefined,
    signalName: string | undefined,
): Promise<ProgramLabel> {
    let variableName = '';
    if (reference?.valueReference) {
        const name = await getName(reference.valueReference);
        if (name) variableName = name;
    }
    if (!variableName) variableName = signalOutput?.value?.toString() ?? '';
    return [
        {
            type: 'primary',
            translationKey: 'program-node-label.single-value',
            interpolateParams: { value: signalName ? `${signalName} = ` : '' },
        },
        {
            type: 'secondary',
            translationKey: 'program-node-label.abbreviations.custom-variable',
            interpolateParams: { variableName: signalName ? variableName : '' },
        },
    ];
}

async function generateSignalOutputLabel(
    signalOutput: SampleSetNode['parameters']['signalOutput'],
    reference?: SampleSetNode['parameters']['reference'],
): Promise<ProgramLabel> {
    const hasValueOrReference = signalOutput?.value !== undefined || reference;
    if (signalOutput?.groupId && signalOutput?.signalID && signalOutput?.sourceID && hasValueOrReference) {
        const signalName = await getSignalName(signalOutput.groupId, signalOutput.sourceID, signalOutput.signalID);
        if (signalOutput.signalValueType === SignalValueTypeEnum.BOOLEAN) {
            const hiLow = signalOutput.value ? 'high' : 'low';
            return [
                {
                    type: 'primary',
                    translationKey: 'program-node-label.single-value',
                    interpolateParams: { value: signalName ? `${signalName} =` : '' },
                },
                {
                    type: 'secondary',
                    translationKey: signalName ? `program-node-label.abbreviations.${hiLow}` : '',
                },
            ];
        }
        if (signalOutput.signalValueType === SignalValueTypeEnum.CUSTOM) {
            return buildVariableReferenceLabel(signalOutput, reference, signalName);
        }
        if (signalOutput.signalValueType === SignalValueTypeEnum.FLOAT && signalOutput.selectedType === 'VARIABLE') {
            return buildVariableReferenceLabel(signalOutput, reference, signalName);
        }
        if (signalOutput.signalValueType === SignalValueTypeEnum.REGISTER && signalOutput.selectedType === 'VARIABLE') {
            return buildVariableReferenceLabel(signalOutput, reference, signalName);
        }
        // When using a literal value for register/modbus signal
        if (typeof signalOutput.value === 'number' || typeof signalOutput.value === 'string') {
            return [
                { type: 'primary', value: signalName ? `${signalName} =` : '' },
                { type: 'secondary', value: signalName ? `${signalOutput.value}` : '' },
            ];
        } else {
            const input = signalOutput.value as Current | Voltage;
            return [
                { type: 'primary', value: signalName ? `${signalName} =` : '' },
                {
                    type: 'secondary',
                    value: `${input.value} ${input.unit}`,
                },
            ];
        }
    }
    return [{ type: 'primary', value: '' }];
}

async function getSignalName(groupId: string, sourceId: string, signalId: string): Promise<string> {
    const api = new ProgramBehaviorAPI(self);
    const signalName = (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceId))).find(
        (signal: Signal) => signal.signalID === signalId,
    )?.name as string;

    if (groupId !== 'ur-robot-io') {
        return signalName;
    }
    return (
        (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceId))).find((signal: Signal) => signal.signalID === signalId)
            ?.name ?? signalId
    );
}

function isUnitOfDomain(unit: CurrentUnit | VoltageUnit, domain: SignalAnalogDomainValueEnum): boolean {
    if ((CurrentUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.CURRENT) {
        return true;
    }
    return (VoltageUnits as readonly string[]).includes(unit) && domain === SignalAnalogDomainValueEnum.VOLTAGE;
}

async function validateSignal(
    signalOutput: SampleSetNode['parameters']['signalOutput'],
    api: ProgramBehaviorAPI,
): Promise<ValidationResponse> {
    if (!signalOutput || !signalOutput.sourceID || !signalOutput.signalID) {
        return { isValid: false, errorMessageKey: 'Signal must be an output signal' };
    }

    const signals = await api.sourceService.getSignals(signalOutput.sourceID);
    const signal = signals.find((s) => s.signalID === signalOutput.signalID);

    if (!signal) {
        return { isValid: false, errorMessageKey: 'Signal not found' };
    }

    if (signal.direction !== SignalDirectionEnum.OUT) {
        return { isValid: false, errorMessageKey: 'Signal must be an output signal' };
    }

    if (signalOutput?.signalValueType !== SignalValueTypeEnum.CUSTOM && signal.valueType !== signalOutput?.signalValueType) {
        return { isValid: false, errorMessageKey: 'Signal value type does not match' };
    }

    return { isValid: true };
}

// ============================================================================
// Upgrade Functions
// ============================================================================

function upgradeTo001(node: SampleSetNode): SampleSetNode {
    if (node.version) {
        return node;
    }
    node.version = '0.0.1';
    return node;
}

async function upgradeTo002(node: SampleSetNode): Promise<SampleSetNode> {
    if (node.version !== '0.0.1') {
        return node;
    }
    node.version = '0.0.2';
    delete (node.parameters as any).type;
    return node;
}

async function upgradeTo003(node: SampleSetNode): Promise<SampleSetNode> {
    if (node.version !== '0.0.2') {
        return node;
    }
    node = await upgradeSourceIds(node);
    node.version = '0.0.3';

    if (node.parameters.signalOutput) {
        // Check if the value matches the valueType of the signal - if yes, set the signalValueType
        let groupId = node.parameters.signalOutput.groupId;
        const { sourceID, signalID, value } = node.parameters.signalOutput;
        // Upgrade fix to handle old sources from ur-tool and ur-wired-io without groupId
        if (!groupId && sourceID && (sourceID.includes('ur-tool') || sourceID.includes('ur-wired'))) {
            groupId = 'robot';
            node.parameters.signalOutput.groupId = groupId;
        }
        if (groupId && sourceID && signalID) {
            const api = new ProgramBehaviorAPI(self);

            const signalValueType = (await firstValueFrom(api.sourceService.sourceSignals(groupId, sourceID)))?.find(
                (signal) => signal.signalID === signalID,
            )?.valueType;

            if (
                (signalValueType === SignalValueTypeEnum.FLOAT && ((value as Current | Voltage)?.value || typeof value === 'number')) ||
                (signalValueType === SignalValueTypeEnum.BOOLEAN && typeof value === 'boolean') ||
                (signalValueType === SignalValueTypeEnum.REGISTER && typeof value === 'number' && parseInt(value.toString()) === value)
            ) {
                node.parameters.signalOutput.signalValueType = signalValueType;
            }
        }
    }
    return node;
}

async function upgradeTo004(node: SampleSetNode): Promise<SampleSetNode> {
    if (node.version !== '0.0.3') {
        return node;
    }
    node.version = '0.0.4';
    return await upgradeSourceIds(node);
}

async function upgradeSourceIds(node: SampleSetNode): Promise<SampleSetNode> {
    const signalOutput = node.parameters.signalOutput;
    if (signalOutput?.groupId === 'robot') {
        signalOutput.groupId = 'ur-robot-io';
        if (signalOutput?.sourceID === 'ur-wired-io') {
            signalOutput.sourceID = 'ur-robot-wired-io';
        }
        if (signalOutput?.sourceID === 'ur-tool-io') {
            signalOutput.sourceID = 'ur-robot-tool-io';
        }
    }
    return node;
}

async function upgradeTo005(node: SampleSetNode): Promise<SampleSetNode> {
    if (node.version !== '0.0.4') {
        return node;
    }
    node.version = '0.0.5';

    // Upgrade variable name to reference
    if (
        node.parameters.signalOutput?.selectedType === 'VARIABLE' &&
        node.parameters.signalOutput?.signalValueType === SignalValueTypeEnum.CUSTOM
    ) {
        node.parameters.reference = await upgradeVariableReference(node.parameters.signalOutput.value?.toString());
    }

    return node;
}

async function upgradeVariableReference(variableName: string | undefined): Promise<SampleSetNodeVariableReference | undefined> {
    if (!variableName) {
        return undefined;
    }
    const matchingVariable = await lookupByName(variableName);
    if (!matchingVariable) {
        return undefined;
    }
    return {
        valueType: matchingVariable.valueType,
        valueReference: matchingVariable.reference,
    };
}
