import { firstValueFrom } from 'rxjs';
import {
    ProgramBehaviorAPI,
    ValidationResponse,
    VariableDeclaration,
    VariableDescriptionWithReference,
    VariableReference,
    VariableService,
    VARIABLE_VALUE_TYPES,
} from '@universal-robots/contribution-api';

export type VariableValueTypeUnion = (typeof VARIABLE_VALUE_TYPES)[number];

// Factory function for VariableService - can be replaced in tests
let variableServiceFactory: () => VariableService = () => new VariableService(self);

export const createVariableService = (): VariableService => variableServiceFactory();

export const setVariableServiceFactory = (factory: () => VariableService): void => {
    variableServiceFactory = factory;
};

export const resetVariableServiceFactory = (): void => {
    variableServiceFactory = () => new VariableService(self);
};

export async function lookupByName(
    variableName: string,
    api: ProgramBehaviorAPI = new ProgramBehaviorAPI(self),
): Promise<VariableDescriptionWithReference | undefined> {
    const variables = await firstValueFrom(api.variableService.variables());
    return variables.find((v) => v.name === variableName);
}

export function lookupByReference(
    reference: VariableReference,
    variables: VariableDescriptionWithReference[],
): VariableDescriptionWithReference | undefined {
    return variables.find((variable) => variable.reference.id === reference.id);
}

export async function getName(
    variable: VariableReference | VariableDeclaration,
    variableService: VariableService = createVariableService(),
): Promise<string | undefined> {
    if (Object.hasOwn(variable, 'name')) {
        return (variable as VariableDeclaration).name;
    }

    const variableWithDescription = await getVariableDescription(variable as VariableReference, variableService);
    return variableWithDescription?.name;
}

export async function getVariableDescription(
    entity: VariableReference,
    variableService: VariableService = createVariableService(),
): Promise<VariableDescriptionWithReference | undefined> {
    return variableService.getVariableDescription(entity);
}

export async function validateVariable(
    reference: VariableReference,
    acceptedTypes: (typeof VARIABLE_VALUE_TYPES)[number][],
    variableService: VariableService = createVariableService(),
): Promise<ValidationResponse> {
    const variableDescription = await variableService.getVariableDescription(reference);

    if (!variableDescription) {
        return { isValid: false, errorMessageKey: 'Variable not found' };
    }

    if (variableDescription.programNodeMetadata?.isSuppressed) {
        return { isValid: false, errorMessageKey: 'Variable is suppressed' };
    }

    const isValidType = acceptedTypes.some((type) => type === variableDescription.valueType);
    if (!isValidType) {
        return { isValid: false, errorMessageKey: 'Assigned value type mismatch' };
    }

    return { isValid: true };
}

export async function getType(
    variable: VariableReference | VariableDeclaration,
    variableService: VariableService = createVariableService(),
): Promise<VariableValueTypeUnion | undefined> {
    if (Object.hasOwn(variable, 'valueType')) {
        return (variable as VariableDeclaration).valueType;
    }

    const variableWithDescription = await getVariableDescription(variable as VariableReference, variableService);
    return variableWithDescription?.valueType;
}

export async function fetchRegisteredVariables(
    variableService: VariableService = createVariableService(),
): Promise<VariableDescriptionWithReference[]> {
    return firstValueFrom(variableService.variables());
}

export async function isRegistered(
    entity: VariableReference | VariableDeclaration,
    variableService: VariableService = createVariableService(),
): Promise<boolean> {
    const variableName = await getName(entity, variableService);
    const registeredVariables = await fetchRegisteredVariables(variableService);
    return registeredVariables.some((v) => v.name === variableName);
}
