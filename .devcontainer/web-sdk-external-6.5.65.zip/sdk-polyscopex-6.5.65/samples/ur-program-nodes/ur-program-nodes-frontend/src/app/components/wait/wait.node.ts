import {
    ProgramNode,
    TabInputModel,
    Time,
    SignalValue,
    SignalValueTypeEnum,
    VARIABLE_VALUE_TYPES,
    VariableReference,
} from '@universal-robots/contribution-api';
import { SelectedType, TabInputValue } from '@universal-robots/ui-models';

export const floatOperators = ['<', '>'] as const;
export const registerOperators = [...floatOperators, '==', '!=', '>=', '<='] as const;
export const operatorInverseMap = {
    '<': '>=',
    '>': '<=',
    '==': '!=',
    '!=': '==',
    '>=': '<',
    '<=': '>',
} as const;

export type floatOperator = (typeof floatOperators)[number];
export type registerOperator = (typeof registerOperators)[number];

export interface SampleWaitNodeSignalInput {
    groupId?: string;
    sourceID?: string;
    signalID?: string;
    selectedType?: SelectedType;
    floatOperator?: floatOperator;
    registerOperator?: registerOperator;
    value?: SignalValue;
    signalValueType?: SignalValueTypeEnum;
}

export interface SampleWaitNodeVariableReference {
    // Additional properties related to the assigned value:
    valueType: (typeof VARIABLE_VALUE_TYPES)[number]; // The last known type of the assignment value. Used for validation - that the assigned value (tapInput component just returns a string) matches the type of the node's referenced variable.
    valueReference?: VariableReference; // If the assignment value is a variable reference, this holds that reference
}

export interface SampleWaitNode extends ProgramNode {
    type: 'ur-sample-node-wait';
    parameters: {
        type: 'time' | 'signalInput' | 'expression';
        time?: TabInputModel<Time>;
        signalInput?: SampleWaitNodeSignalInput;
        expression?: TabInputValue;
        reference?: SampleWaitNodeVariableReference;
    };
}
