import { ChangeDetectionStrategy, Component, computed, EventEmitter, input, Output } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import {
    AccelerationUnit,
    AngularAccelerationUnit,
    AngularSpeedUnit,
    convertValue,
    MoveToSpeedSettings,
    MoveType,
    SpeedUnit,
    TabInputModel,
    URVariable,
    Value,
    valueRawConverter,
    AllUnits,
} from '@universal-robots/contribution-api';
import { DropdownOption, InputValidator, SelectedInput, TabInputInsertableModel, TabInputValue } from '@universal-robots/ui-models';
import { Acceleration, AngularSpeed, CONCEPT_UNITS, Unit, UnitEnum, Units } from '@universal-robots/utilities-units';
import { getConvertedTabInputValue } from '../../tabinput-helper';
import { getRangeErrorString } from '../../validator-helper';
import { MoveConstraints, Movement_Classic, Movement_Optimove } from '../move-to.constants';

@Component({
    selector: 'ur-move-to-speed-settings',
    templateUrl: './speed-settings.component.html',
    styleUrls: ['./speed-settings.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SpeedSettingsComponent {
    speedSettings = input.required<MoveToSpeedSettings>();
    moveType = input.required<MoveType>();
    units = input.required<Units>();
    variables = input.required<URVariable[]>();
    insertables = input.required<TabInputInsertableModel>();

    @Output()
    speedSettingsChanged = new EventEmitter<MoveToSpeedSettings>();

    speedUnit = computed(() => (this.moveType() === 'moveJ' ? this.units().ANGULAR_SPEED : this.units().SPEED));
    accelerationUnit = computed(() => (this.moveType() === 'moveJ' ? this.units().ANGULAR_ACCELERATION : this.units().ACCELERATION));
    convertedSpeed = computed(() =>
        getConvertedTabInputValue(this.speedSettings().speed, (value: Value) =>
            valueRawConverter(value, this.speedUnit() as Unit<AngularSpeed>),
        ),
    );
    convertedAcceleration = computed(() =>
        getConvertedTabInputValue(this.speedSettings().acceleration, (value: Value) =>
            valueRawConverter(value, this.accelerationUnit() as Unit<Acceleration>),
        ),
    );
    getOptiSpeed = computed(() => TabInputModel.getTabInputValue(this.speedSettings().optiMoveSpeed));
    getOptiAcceletation = computed(() => TabInputModel.getTabInputValue(this.speedSettings().optiMoveAcceleration));

    motionValueOptions: DropdownOption[];

    constructor(private readonly translateService: TranslateService) {
        this.motionValueOptions = [
            {
                value: Movement_Optimove,
                label: this.translateService.instant('presenter.move-to.label.optimove'),
            },
            {
                value: Movement_Classic,
                label: this.translateService.instant('presenter.move-to.label.classic'),
            },
        ];
    }

    setMotionValue(motionValue: DropdownOption) {
        this.speedSettingsChanged.emit({ ...this.speedSettings(), motionValue: motionValue.value as string });
    }

    private updateSpeedSetting(
        key: keyof MoveToSpeedSettings,
        $event: TabInputValue,
        getUnit?: () => { label: AllUnits },
        siUnit?: SpeedUnit | AccelerationUnit | AngularSpeedUnit | AngularAccelerationUnit,
    ) {
        const inputValue = $event.value;

        const setting = { ...structuredClone(this.speedSettings()[key] as TabInputModel<Value>), selectedType: $event.selectedType };

        if ($event.selectedType === SelectedInput.VALUE) {
            if (getUnit && siUnit) {
                const valueWithUnit = {
                    value: Number(inputValue),
                    unit: getUnit().label,
                } as Value<SpeedUnit | AccelerationUnit | AngularSpeedUnit | AngularAccelerationUnit>;
                const converted = convertValue(valueWithUnit, siUnit);
                setting.entity = converted;
                setting.value = converted.value;
            } else {
                setting.value = inputValue;
                setting.entity.value = Number(inputValue);
            }
        } else {
            setting.value = inputValue;
        }

        this.speedSettingsChanged.emit({
            ...this.speedSettings(),
            [key]: setting,
        });
    }

    setSpeed($event: TabInputValue) {
        const siUnit = this.moveType() === 'moveJ' ? 'rad/s' : 'm/s';
        this.updateSpeedSetting('speed', $event, this.speedUnit.bind(this), siUnit);
    }

    setAcceleration($event: TabInputValue) {
        const siUnit = this.moveType() === 'moveJ' ? 'rad/s^2' : 'm/s^2';
        this.updateSpeedSetting('acceleration', $event, this.accelerationUnit.bind(this), siUnit);
    }

    setOptiMoveSpeed($event: TabInputValue) {
        this.updateSpeedSetting('optiMoveSpeed', $event);
    }

    setOptiMoveAcceleration($event: TabInputValue) {
        this.updateSpeedSetting('optiMoveAcceleration', $event);
    }

    public validateSpeed: InputValidator = (val: string | number) => {
        return getRangeErrorString(Number(val), MoveConstraints[this.moveType()].speed, this.units(), this.translateService);
    };

    public validateAcceleration: InputValidator = (val: string | number) => {
        return getRangeErrorString(Number(val), MoveConstraints[this.moveType()].acceleration, this.units(), this.translateService);
    };

    public getInputLabelText(unit: UnitEnum) {
        return this.translateService.instant('presenter.move.label.input_help') + ' ' + CONCEPT_UNITS[unit].symbol;
    }

    protected readonly Movement_Classic = Movement_Classic;
}
