import {
    ChangeDetectionStrategy,
    Component,
    computed,
    inject,
    OnChanges,
    Signal,
    signal,
    SimpleChanges,
    WritableSignal,
} from '@angular/core';
import { toObservable, toSignal } from '@angular/core/rxjs-interop';
import { TranslateService } from '@ngx-translate/core';
import { combineLatest, firstValueFrom, map, mergeMap, of, switchMap } from 'rxjs';
import {
    Signal as SourceSignal,
    SignalDirectionEnum,
    SignalValue,
    SignalValueTypeEnum,
    Source,
    Value,
    ValueRange,
    VariableDescriptionWithReference,
} from '@universal-robots/contribution-api';
import { URPortalService, URTabInputContainerComponent } from '@universal-robots/ui-angular-components';
import {
    DropdownOption,
    SelectedInput,
    TabInputData,
    TabInputInsertableModel,
    TabInputValue,
    TabInputValueType,
} from '@universal-robots/ui-models';
import { CommonProgramPresenterComponent } from '../common-program-presenter.component';
import { SampleSetNode, SampleSetNodeVariableReference } from './set.node';

type SourceDropdownOption = DropdownOption & { groupId: string; groupIdName: string; value: string };

@Component({
    templateUrl: './set.component.html',
    styleUrls: ['./set.component.scss'],
    changeDetection: ChangeDetectionStrategy.OnPush,
    standalone: false,
})
export class SetComponent extends CommonProgramPresenterComponent<SampleSetNode> implements OnChanges {
    protected translateService = inject(TranslateService);
    private dialogService = inject(URPortalService);

    selectedSignalOutput = signal<SampleSetNode['parameters']['signalOutput'] | undefined>(undefined);
    isValid: WritableSignal<boolean> = signal(true);
    expressionInsertables = signal<TabInputInsertableModel | undefined>(undefined);

    selectedSourceSignal = computed(() =>
        this.signals()?.find((sourceSignal) => sourceSignal.signalID === this.selectedSignalOutput()?.signalID),
    );
    selectedSourceOption = computed(() => this.sourcesOptions()?.find((option) => option.value === this.selectedSignalOutput()?.sourceID));

    sourcesOptions = computed(() =>
        Object.entries(this.sources()).flatMap(([groupId, sources]) =>
            sources.map((source) => ({
                label: groupId === 'robot' ? this.translateService.instant(source.sourceID) : source.name || source.sourceID,
                value: source.sourceID,
                groupId,
                groupIdName:
                    groupId === 'robot'
                        ? this.translateService.instant(`communication.nodes.robot.title`)
                        : this.sourceNodeLabels()[groupId] || groupId,
            })),
        ),
    );

    selectedSignalValueType = computed(() => this.typeMap[this.selectedSignalType() || 'DEFAULT']);

    selectedSignalType = computed(
        () => this.signals()?.find((signal) => signal.signalID === this.selectedSignalOutput()?.signalID)?.valueType,
    );

    selectedSignalOption = computed(() => {
        const signalOutput = this.selectedSignalOutput();
        const value = signalOutput?.value;
        const option = this.digitalValueOptions().find((opt) => opt.value === value);
        if (option) return option;
        const displayName = this.contributedNode.parameters.reference ? this.resolvedVariableName() : value;
        if (displayName != null && displayName !== '') {
            const invalid = typeof displayName === 'number' ? false : !this.isVariableAvailable(String(displayName));
            return {
                label: `${displayName}`,
                value: displayName,
                invalid,
            };
        }
        return undefined;
    });

    selectedSignalTabOption = computed(() => {
        const signalOutput = this.selectedSignalOutput();
        const selectedType = signalOutput?.selectedType;
        const value =
            selectedType === 'VARIABLE' && this.contributedNode.parameters.reference
                ? (this.resolvedVariableName() ?? 'undefined')
                : ((signalOutput?.value as Value)?.value ?? signalOutput?.value ?? 'undefined');
        return { selectedType, value };
    });

    digitalValueOptions = computed(() => {
        this.onLangChange();
        const options: Array<DropdownOption> = [
            { label: this.translateService.instant('high'), value: true },
            { label: this.translateService.instant('low'), value: false },
        ];
        if (this.selectedSignalOutput()?.signalValueType !== SignalValueTypeEnum.CUSTOM) {
            return options;
        }
        const selectedType = this.contributedNode.parameters.signalOutput?.selectedType;
        const displayName = this.resolvedVariableName() ?? this.selectedSignalOutput()?.value;
        if (displayName != null && displayName !== '') {
            options.push({
                label: `${displayName}`,
                value: displayName,
                invalid: selectedType === 'EXPRESSION' ? false : !this.isVariableAvailable(String(displayName)),
            });
        }
        return options;
    });

    sourceNodeLabels: Signal<{ [groupId: string]: string }> = toSignal(
        toObservable(this.api).pipe(switchMap((presenterAPI) => presenterAPI?.sourceService.sourceNodeLabels() ?? of({}))),
        { initialValue: {} },
    );

    variables: Signal<VariableDescriptionWithReference[]> = toSignal(
        toObservable(this.api).pipe(switchMap((presenterAPI) => presenterAPI?.variableService.variables() ?? of([]))),
        { initialValue: [] },
    );

    sources: Signal<{ [groupId: string]: Array<Source> }> = toSignal(
        toObservable(this.api).pipe(
            switchMap((presenterAPI) => {
                if (presenterAPI) {
                    return presenterAPI.sourceService.sources({
                        direction: SignalDirectionEnum.OUT,
                    });
                }
                return of({});
            }),
        ),
        { initialValue: {} },
    );
    signals = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), toObservable(this.api)]).pipe(
            mergeMap(([selectedSignalOutput, presenterAPI]) => {
                if (!selectedSignalOutput) {
                    return [];
                }
                const { groupId, sourceID } = selectedSignalOutput;
                if (presenterAPI && groupId && sourceID) {
                    return firstValueFrom(
                        presenterAPI.sourceService.sourceSignals(groupId, sourceID, {
                            direction: SignalDirectionEnum.OUT,
                        }),
                    );
                }
                return [];
            }),
            map((signals) =>
                signals.filter((signal) =>
                    [SignalValueTypeEnum.BOOLEAN, SignalValueTypeEnum.FLOAT, SignalValueTypeEnum.REGISTER].some(
                        (valueType) => valueType === signal.valueType,
                    ),
                ),
            ),
            mergeMap((signals) => this.filterSafetyOutputs(signals)),
        ),
    );
    domains: Signal<Record<string, ValueRange> | undefined> = toSignal(
        combineLatest([toObservable(this.selectedSignalOutput), toObservable(this.api)]).pipe(
            mergeMap(([selectedSignalInput, presenterAPI]) => {
                const sourceId = selectedSignalInput?.sourceID;
                if (presenterAPI && sourceId) {
                    return presenterAPI.sourceService.getSignalsDomainData(selectedSignalInput.groupId || '', sourceId);
                }
                return of({});
            }),
        ),
    );

    onLangChange = toSignal(this.translateService.onLangChange);

    readonly SignalValueType = SignalValueTypeEnum;
    readonly valueValidators = [this.validateValue.bind(this)];
    readonly onUseVariable = () => this.setTabInputValue();

    private readonly typeMap: { [key: string]: TabInputValueType[] } = {
        BOOLEAN: ['boolean'],
        FLOAT: ['integer', 'float'],
        REGISTER: ['integer', 'float'],
        DEFAULT: ['integer', 'float', 'string', 'boolean'],
    };

    async ngOnChanges(changes: SimpleChanges) {
        await super.ngOnChanges(changes);

        if (changes.presenterAPI) {
            this.expressionInsertables.set(await changes.presenterAPI.currentValue.expressionEditorService?.getTabInputInsertableModel());
        }

        if (changes.contributedNode) {
            this.selectedSignalOutput.set(changes.contributedNode.currentValue.parameters.signalOutput);
        }
    }

    signalLabelFactory = (signal: SourceSignal) => signal?.name || signal.signalID;

    digitalValueFactory = (option: any) =>
        option.value === 'custom' && this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM
            ? this.selectedSignalOutput()?.value
            : option.label;

    async setSourceID($event: SourceDropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        this.contributedNode.parameters.signalOutput.sourceID = $event.value;
        this.contributedNode.parameters.signalOutput.groupId = $event.groupId;
        this.contributedNode.parameters.signalOutput.signalID = undefined;
        this.contributedNode.parameters.signalOutput.value = undefined;
        this.contributedNode.parameters.reference = undefined;
        this.saveNode();
    }

    setSignalID($event: SourceSignal) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        this.contributedNode.parameters.signalOutput.signalID = $event.signalID;
        this.contributedNode.parameters.signalOutput.signalValueType = $event.valueType;

        this.resetSignalOutputValue($event.valueType, $event.signalID);
        this.saveNode();
    }

    async setValue($event: TabInputValue) {
        if (this.selectedSignalType() === SignalValueTypeEnum.REGISTER) {
            await this.setRegisterValue($event);
            return;
        }
        await this.setAnalogTabInput($event);
    }

    async setDigitalValue($event: DropdownOption) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }

        if (typeof $event.value === 'boolean') {
            this.contributedNode.parameters.signalOutput = {
                ...this.contributedNode.parameters.signalOutput,
                value: $event.value,
                signalValueType: SignalValueTypeEnum.BOOLEAN,
                selectedType: undefined,
            };
            this.saveNode();
        }
    }

    validateValue(val: number) {
        const signalDomainData = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (signalDomainData !== undefined) {
            return this.getDomainDataErrorString(val, signalDomainData);
        }
        return null;
    }

    getAnalogUnit() {
        const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
        if (domain !== undefined && this.selectedSignalOutput()?.selectedType === 'VALUE') {
            return domain.unit;
        }
        return null;
    }

    async setRegisterValue($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput) {
            this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;
            const { value, reference } = this.getVariableReferenceValues($event, this.variables());
            this.contributedNode.parameters.signalOutput.value = value;
            this.contributedNode.parameters.reference = reference;
            this.saveNode();
        }
    }

    async setTabInputValue() {
        const inputData = this.createTabInputData();
        const { reason, returnData } = await firstValueFrom(
            this.dialogService.open<TabInputValue>(URTabInputContainerComponent, inputData).afterClose,
        );

        if (reason === 'CONFIRMED' && this.contributedNode.parameters.signalOutput && returnData) {
            this.contributedNode.parameters.signalOutput.signalValueType = SignalValueTypeEnum.CUSTOM;
            this.contributedNode.parameters.signalOutput.selectedType = returnData.selectedType;
            const { value, reference } = this.getVariableReferenceValues(returnData, this.variables());
            this.contributedNode.parameters.signalOutput.value = value;
            this.contributedNode.parameters.reference = reference;
            this.saveNode();
        }
    }

    private getVariableReferenceValues(
        tabInputValue: TabInputValue,
        variables: VariableDescriptionWithReference[],
    ): { value: SignalValue | undefined; reference: SampleSetNodeVariableReference | undefined } {
        if (tabInputValue.selectedType === 'VARIABLE') {
            const variableName = String(tabInputValue.value);
            const matchingVariable = variables.find((v) => v.name === variableName);
            return {
                value: undefined,
                reference: matchingVariable
                    ? { valueType: matchingVariable.valueType, valueReference: matchingVariable.reference }
                    : undefined,
            };
        }
        return {
            value: tabInputValue.value as SignalValue,
            reference: undefined,
        };
    }

    /** Resolves the current variable name from parameters.reference using the variables list (e.g. after rename). */
    private resolvedVariableName = computed(() => {
        const ref = this.contributedNode.parameters.reference?.valueReference;
        if (!ref?.id) return undefined;
        return this.variables().find((v) => v.reference?.id === ref.id)?.name;
    });

    private resetSignalOutputValue(valueType: SignalValueTypeEnum, signalID: string) {
        if (!this.contributedNode.parameters.signalOutput) {
            return;
        }
        const domain = getSignalValueRange(this.domains(), signalID);
        this.contributedNode.parameters.signalOutput.selectedType = undefined;
        this.contributedNode.parameters.signalOutput.value = 0;

        if (valueType === SignalValueTypeEnum.FLOAT) {
            this.contributedNode.parameters.signalOutput.selectedType = 'VALUE';
            if (domain !== undefined) {
                this.contributedNode.parameters.signalOutput.value = {
                    value: domain.min,
                    unit: domain.unit,
                };
            }
        }

        if (valueType === SignalValueTypeEnum.BOOLEAN) {
            this.contributedNode.parameters.signalOutput.value = true;
        }
    }

    private async setAnalogTabInput($event: TabInputValue) {
        if (this.contributedNode.parameters.signalOutput === undefined) {
            return;
        }

        this.contributedNode.parameters.signalOutput.selectedType = $event.selectedType;

        if ($event.selectedType === 'VARIABLE') {
            const { value, reference } = this.getVariableReferenceValues($event, this.variables());
            this.contributedNode.parameters.signalOutput.value = value;
            this.contributedNode.parameters.reference = reference;
        } else {
            const domain = getSignalValueRange(this.domains(), this.contributedNode.parameters.signalOutput?.signalID);
            if (domain !== undefined && $event.selectedType === 'VALUE') {
                this.contributedNode.parameters.signalOutput.value = { value: Number($event.value), unit: domain.unit };
            } else {
                this.contributedNode.parameters.signalOutput.value = $event.value;
            }
            this.contributedNode.parameters.reference = undefined;
        }

        this.saveNode();
    }

    private createTabInputData(): TabInputData {
        return {
            inputLabel: '',
            placeholder: '',
            translations: {},
            type: 'text',
            label: this.translateService.instant('presenter.set.expression'),
            valueType: ['boolean'],
            insertables: this.expressionInsertables(),
            tabInputValue: {
                selectedType: this.selectedSignalOutput()?.selectedType ?? SelectedInput.VARIABLE,
                value:
                    this.selectedSignalOutput()?.signalValueType === SignalValueTypeEnum.CUSTOM
                        ? (this.resolvedVariableName() ?? this.selectedSignalOutput()?.value ?? (undefined as any))
                        : (undefined as any),
            },
            tabs: [SelectedInput.VARIABLE, SelectedInput.EXPRESSION],
        };
    }

    private isVariableAvailable(varName: string) {
        return this.variables().some((item) => item.name === varName && !item.programNodeMetadata?.isSuppressed);
    }

    private getDomainDataErrorString(val: number, constraints: ValueRange): string | null {
        return this.getRangeErrorString(val, {
            lowerLimit: constraints.min,
            upperLimit: constraints.max,
            unit: constraints.unit,
        });
    }

    private async filterSafetyOutputs(signals: SourceSignal[]): Promise<SourceSignal[]> {
        const safetyOutputs = await this.getSafetyOutputs();
        return signals.filter((signal) => !this.isSignalUsedBySafetyIOs(signal.signalID, safetyOutputs));
    }

    private async getSafetyOutputs(): Promise<{ name: string; valueA: number; valueB: number }[]> {
        if (!this.presenterAPI) {
            return [];
        }
        const safetyIOs = await this.presenterAPI.safetyService.getIOs();
        if (safetyIOs === undefined) {
            return [];
        }
        return Object.values(safetyIOs).filter((io) => io.name.includes('Output'));
    }

    private isSignalUsedBySafetyIOs(
        signalID: string,
        safetyOutputs: {
            name: string;
            valueA: number;
            valueB: number;
        }[],
    ): boolean {
        return safetyOutputs.some((output) => 'CO ' + output.valueA === signalID || 'CO ' + output.valueB === signalID);
    }
}

const getSignalValueRange = (domains: Record<string, ValueRange> | undefined, signalID: string | undefined) => {
    if (signalID && domains && Object.hasOwnProperty.call(domains, signalID)) {
        return Reflect.get(domains, signalID) as ValueRange;
    }
    return undefined;
};
