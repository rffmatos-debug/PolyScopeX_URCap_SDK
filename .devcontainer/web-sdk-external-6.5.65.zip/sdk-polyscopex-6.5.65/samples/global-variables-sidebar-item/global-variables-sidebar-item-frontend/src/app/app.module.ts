import { HttpBackend, HttpClientModule } from '@angular/common/http';
import { DoBootstrap, Injector, NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { createCustomElement } from '@angular/elements';
import { BrowserModule } from '@angular/platform-browser';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { MultiTranslateHttpLoader } from 'ngx-translate-multi-http-loader';
import { UIAngularComponentsModule } from '@universal-robots/ui-angular-components';
import { PATH } from '../generated/contribution-constants';
import { GlobalVariablesComponent } from './components/global-variables/global-variables.component';

export const httpLoaderFactory = (http: HttpBackend) =>
    new MultiTranslateHttpLoader(http, [
        { prefix: PATH + '/assets/i18n/', suffix: '.json' },
        { prefix: './ui/assets/i18n/', suffix: '.json' },
    ]);

@NgModule({
    declarations: [GlobalVariablesComponent],
    schemas: [CUSTOM_ELEMENTS_SCHEMA],
    imports: [
        BrowserModule,
        BrowserAnimationsModule,
        UIAngularComponentsModule,
        HttpClientModule,
        TranslateModule.forRoot({
            loader: {
                provide: TranslateLoader,
                useFactory: httpLoaderFactory,
                deps: [HttpBackend],
            },
        }),
    ],
    providers: [],
})
export class AppModule implements DoBootstrap {
    constructor(private injector: Injector) {}

    ngDoBootstrap() {
        const globalvariablesComponent = createCustomElement(GlobalVariablesComponent, { injector: this.injector });
        customElements.define('global-variables-sidebar-item', globalvariablesComponent);
    }

    // This function is never called, because we don't want to actually use the workers, just tell webpack about them
    registerWorkersWithWebPack() {
        new Worker(new URL('./components/global-variables/global-variables-sidebar-item.worker.ts', import.meta.url), {
            name: 'global-variables-sidebar-item-worker',
            type: 'module',
        });
    }
}
